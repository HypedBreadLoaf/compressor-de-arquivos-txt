/*
 * gera_testes.c - Gera os arquivos dos tres cenarios de redundancia usados
 * nos testes de desempenho do UFABC BWZip.
 *
 *   baixa_redundancia.bin  bytes pseudoaleatorios: nada a comprimir
 *   media_redundancia.wav  audio PCM de 16 bits sem compressao (passeio
 *                          aleatorio): o byte alto de cada amostra varia
 *                          pouco, mas o byte baixo e quase aleatorio
 *   alta_redundancia.log   registro de acessos de um servidor web: poucas
 *                          linhas diferentes, repetidas com pequenas variacoes
 *   baixa_redundancia_texto.txt
 *                          texto de caracteres sorteados (letras, digitos,
 *                          pontuacao e espacos): cada caractere e
 *                          imprevisivel, mas so 95 dos 256 valores de byte
 *                          aparecem (log2 95 = 6,57 bits de informacao em
 *                          cada 8) e a cada 80 bytes ha um '\n' previsivel,
 *                          entao nenhum compressor passa de R = 0,81
 *
 * Uso: gera_testes <pasta> [tamanho de cada arquivo em MiB, padrao 10]
 *
 * O gerador pseudoaleatorio (xorshift32, Marsaglia 2003) tem semente fixa,
 * entao os arquivos gerados sao sempre os mesmos.
 */
#include <stdio.h>
#include <stdlib.h>

#define TAM_CAMINHO 1024

static unsigned long estado = 2463534242UL;

static unsigned long aleatorio(void)
{
    estado = (estado ^ (estado << 13)) & 0xFFFFFFFFUL;
    estado ^= estado >> 17;
    estado = (estado ^ (estado << 5)) & 0xFFFFFFFFUL;
    return estado;
}

/* Inteiro em [0, n) */
static int sorteia(int n)
{
    return (int) (aleatorio() % (unsigned long) n);
}

static FILE *cria(const char *pasta, const char *nome)
{
    char caminho[TAM_CAMINHO];
    FILE *f;

    if (sprintf(caminho, "%.900s/%s", pasta, nome) < 0)
        return NULL;
    f = fopen(caminho, "wb");
    if (f == NULL)
        printf("Nao foi possivel criar %s\n", caminho);
    else
        printf("Gerando %s\n", caminho);
    return f;
}

static void gera_baixa(FILE *f, long tamanho)
{
    long i;

    for (i = 0; i < tamanho; i++)
        fputc((int) (aleatorio() & 0xFF), f);
}

/* Linhas de 79 caracteres sorteados entre os 95 imprimiveis do ASCII
   (do espaco ao '~'), cada uma terminada por '\n' */
static void gera_baixa_texto(FILE *f, long tamanho)
{
    long i;

    for (i = 1; i <= tamanho; i++)
        fputc(i % 80 == 0 ? '\n' : ' ' + sorteia(95), f);
}

static void escreve_u16(FILE *f, unsigned long valor)
{
    fputc((int) (valor & 0xFF), f);
    fputc((int) ((valor >> 8) & 0xFF), f);
}

static void escreve_u32(FILE *f, unsigned long valor)
{
    escreve_u16(f, valor & 0xFFFF);
    escreve_u16(f, (valor >> 16) & 0xFFFF);
}

/* Arquivo WAV: cabecalho de 44 bytes e amostras mono de 16 bits a 44,1 kHz */
static void gera_media(FILE *f, long tamanho)
{
    long i, n = (tamanho - 44) / 2;
    int amostra = 0;

    fputs("RIFF", f);
    escreve_u32(f, 36 + 2 * (unsigned long) n);
    fputs("WAVEfmt ", f);
    escreve_u32(f, 16);         /* tamanho do bloco "fmt " */
    escreve_u16(f, 1);          /* PCM */
    escreve_u16(f, 1);          /* mono */
    escreve_u32(f, 44100);      /* amostras por segundo */
    escreve_u32(f, 88200);      /* bytes por segundo */
    escreve_u16(f, 2);          /* bytes por amostra */
    escreve_u16(f, 16);         /* bits por amostra */
    fputs("data", f);
    escreve_u32(f, 2 * (unsigned long) n);

    for (i = 0; i < n; i++) {
        amostra += sorteia(129) - 64;
        if (amostra > 20000)
            amostra = 40000 - amostra;
        if (amostra < -20000)
            amostra = -40000 - amostra;
        escreve_u16(f, (unsigned long) (amostra + 65536) & 0xFFFF);
    }
}

static void gera_alta(FILE *f, long tamanho)
{
    static const char *const caminhos[] = {
        "/", "/index.html", "/css/estilo.css", "/js/app.js", "/img/logo.png",
        "/api/alunos", "/api/turmas", "/login", "/moodle/course/view.php", "/favicon.ico"
    };
    static const char *const navegadores[] = {
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Firefox/128.0",
        "Mozilla/5.0 (X11; Linux x86_64) Chrome/126.0",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5) Safari/604.1"
    };
    static const long bytes[] = { 5120, 5120, 18432, 73728, 9216, 1536, 1024, 2048, 40960, 1150 };
    long escritos = 0;
    int c, status, hora = 8, minuto = 0, segundo = 0;

    while (escritos < tamanho) {
        c = sorteia(10);
        status = sorteia(50) == 0 ? 404 : 200;
        escritos += fprintf(f, "200.17.%d.%d - - [28/Oct/2026:%02d:%02d:%02d -0300] "
                            "\"GET %s HTTP/1.1\" %d %ld \"-\" \"%s\"\n",
                            sorteia(4), 10 + sorteia(20), hora, minuto, segundo,
                            caminhos[c], status, status == 200 ? bytes[c] : 512L,
                            navegadores[sorteia(3)]);
        segundo += sorteia(3);
        if (segundo >= 60) {
            segundo -= 60;
            if (++minuto == 60) {
                minuto = 0;
                hora = (hora + 1) % 24;
            }
        }
    }
}

int main(int argc, char *argv[])
{
    long tamanho;
    FILE *f;
    int erros = 0;

    if (argc < 2) {
        printf("Uso: %s <pasta> [tamanho em MiB]\n", argv[0]);
        return 1;
    }
    tamanho = (argc > 2 ? atol(argv[2]) : 10L) * 1048576L;
    if (tamanho <= 0) {
        printf("Tamanho invalido.\n");
        return 1;
    }

    f = cria(argv[1], "baixa_redundancia.bin");
    if (f != NULL) {
        gera_baixa(f, tamanho);
        erros += fclose(f) != 0;
    } else {
        erros++;
    }
    f = cria(argv[1], "media_redundancia.wav");
    if (f != NULL) {
        gera_media(f, tamanho);
        erros += fclose(f) != 0;
    } else {
        erros++;
    }
    f = cria(argv[1], "alta_redundancia.log");
    if (f != NULL) {
        gera_alta(f, tamanho);
        erros += fclose(f) != 0;
    } else {
        erros++;
    }
    f = cria(argv[1], "baixa_redundancia_texto.txt");
    if (f != NULL) {
        gera_baixa_texto(f, tamanho);
        erros += fclose(f) != 0;
    } else {
        erros++;
    }
    return erros == 0 ? 0 : 1;
}
