/*
 * huffman.h - TAD Arvore de Codificacao de Huffman.
 *
 * A arvore e usada para calcular o comprimento do codigo de cada simbolo.
 * Os codigos sao atribuidos na forma canonica: codigos de mesmo comprimento
 * sao consecutivos, em ordem de simbolo. Assim, basta gravar os
 * comprimentos no arquivo para que o decodificador reconstrua os codigos.
 */
#ifndef HUFFMAN_H
#define HUFFMAN_H

#include "bits.h"

#define HUF_MAX_SIMBOLOS 258    /* RUNA, RUNB, 255 posicoes MTF e FIM (bloco.c) */
#define HUF_MAX_COMPRIMENTO 17  /* maior codigo permitido, em bits */

/* Comprimentos (1..HUF_MAX_COMPRIMENTO) dos codigos de n >= 2 simbolos.
   Simbolos de frequencia 0 tambem recebem codigo. */
void huf_comprimentos(const unsigned long *freq, int n, unsigned char *comp);

/* Codigos canonicos a partir dos comprimentos */
void huf_codigos(const unsigned char *comp, int n, unsigned int *codigos);

typedef struct {
    int contagem[HUF_MAX_COMPRIMENTO + 1];  /* quantidade de codigos de cada comprimento */
    int simbolos[HUF_MAX_SIMBOLOS];         /* simbolos na ordem canonica */
} DecodificadorHuffman;

void huf_prepara(DecodificadorHuffman *d, const unsigned char *comp, int n);

/* Le um simbolo; retorna -1 se os bits nao formarem um codigo valido */
int huf_decodifica(const DecodificadorHuffman *d, FluxoBits *fb);

#endif
