/*
 * crc32.h - Codigo de verificacao CRC-32 (o mesmo usado pelo zip, gzip e PNG).
 *
 * O CRC-32 e uma "impressao digital" de 32 bits dos dados. O compressor
 * grava o CRC-32 do arquivo original e o descompressor o recalcula sobre os
 * dados restaurados: se os dois forem diferentes, o arquivo comprimido foi
 * alterado ou danificado. Qualquer erro concentrado em ate 32 bits seguidos
 * e sempre detectado; os demais escapam com chance de 1 em 2^32.
 */
#ifndef CRC32_H
#define CRC32_H

/* Continua o calculo do CRC-32 com mais n bytes. Comece com crc = 0.
   Calcular o CRC de A e continuar com B da o mesmo resultado que calcular
   o CRC de A seguido de B de uma so vez. */
unsigned long crc32_atualiza(unsigned long crc, const unsigned char *dados, unsigned long n);

#endif
