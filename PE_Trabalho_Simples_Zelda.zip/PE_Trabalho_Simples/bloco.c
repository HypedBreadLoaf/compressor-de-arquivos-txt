/*
 * bloco.c - Codificacao de um bloco transformado pela BWT.
 *
 * 1. Move-to-Front (MTF): cada byte e trocado pela sua posicao em uma lista
 *    de bytes recentes. Na saida da BWT isso gera principalmente zeros e
 *    numeros pequenos. Na variante MTF-2 (Balkenhol, Kurtz e Shtarkov, 1999)
 *    o byte usado vai para a posicao 1, e nao para a frente; so chega a
 *    frente se for usado de novo, exceto logo apos uma repeticao do byte da
 *    frente. Assim, um byte isolado nao tira da frente o byte que se repete.
 * 2. Sequencias de zeros sao gravadas pelo seu tamanho em base 2 bijetiva,
 *    com os digitos RUNA (1) e RUNB (2), como no bzip2.
 * 3. Os simbolos sao divididos em grupos de 50 e cada grupo usa a tabela de
 *    Huffman mais barata para ele, entre 2 a 7 tabelas otimizadas juntas.
 *    Cada tabela e um TAD Dicionario (dicionario.h).
 *
 * Bloco codificado (bits):
 *   bytes usados (256) | numero de tabelas (3) | numero de grupos (24)
 *   | tabela de cada grupo | comprimentos dos codigos | simbolos
 */
#include "bloco.h"
#include "bits.h"
#include "dicionario.h"

#define RUNA 0          /* digito 1 do tamanho de uma sequencia de zeros */
#define RUNB 1          /* digito 2 do tamanho de uma sequencia de zeros */
#define TAM_GRUPO 50    /* simbolos codificados com a mesma tabela */
#define MAX_TABELAS 7   /* gravado em 3 bits */
#define ITERACOES 4     /* refinamentos das tabelas */

/* tabela de Huffman usada por cada grupo (um bloco tem ate n+1 simbolos) */
static unsigned char seletores[BLOCO_MAXIMO / TAM_GRUPO + 2];

/* Move lista[j] para a posicao 'destino' (destino <= j), deslocando os
   itens intermediarios uma posicao para tras. Retorna o item movido. */
static unsigned char move(unsigned char *lista, int j, int destino)
{
    unsigned char item = lista[j];

    for (; j > destino; j--)
        lista[j] = lista[j - 1];
    lista[destino] = item;
    return item;
}

/* Posicao para onde o MTF-2 leva o byte usado da posicao j >= 1 */
static int destino_mtf2(int j, int repetiu)
{
    return j == 1 && !repetiu ? 0 : 1;
}

/* ---------------------------------------------------------------------- */
/* Codificacao                                                            */
/* ---------------------------------------------------------------------- */

/* Grava o tamanho de uma sequencia de zeros em base 2 bijetiva */
static int emite_zeros(unsigned short *simbolos, int total, int zeros)
{
    while (zeros > 0) {
        if (zeros % 2 == 1) {
            simbolos[total++] = RUNA;
            zeros = (zeros - 1) / 2;
        } else {
            simbolos[total++] = RUNB;
            zeros = (zeros - 2) / 2;
        }
    }
    return total;
}

/* MTF-2 + sequencias de zeros. Gera RUNA/RUNB, a posicao MTF + 1 dos demais
   bytes e, no fim, o simbolo FIM (n_usados + 1). Retorna quantos gerou. */
static int mtf_codifica(const unsigned char *bwt, int n, const unsigned char *usado,
                        unsigned short *simbolos)
{
    unsigned char lista[256];
    int i, j, n_usados = 0, total = 0, zeros = 0, repetiu = 0;

    for (i = 0; i < 256; i++)
        if (usado[i])
            lista[n_usados++] = (unsigned char) i;

    for (i = 0; i < n; i++) {
        if (bwt[i] == lista[0]) {
            zeros++;
            repetiu = 1;
            continue;
        }
        total = emite_zeros(simbolos, total, zeros);
        zeros = 0;
        j = 1;
        while (lista[j] != bwt[i])
            j++;
        simbolos[total++] = (unsigned short) (j + 1);
        move(lista, j, destino_mtf2(j, repetiu));
        repetiu = 0;
    }
    total = emite_zeros(simbolos, total, zeros);
    simbolos[total++] = (unsigned short) (n_usados + 1);
    return total;
}

/* Otimiza as tabelas: comeca dividindo os grupos em faixas consecutivas,
   uma por tabela; depois, a cada iteracao, cada grupo escolhe a tabela mais
   barata para ele e as tabelas sao recalculadas com as frequencias dos
   grupos que as escolheram. */
static void otimiza_tabelas(const unsigned short *simbolos, int total, int alfabeto,
                            int n_tabelas, Dicionario *dic)
{
    unsigned long custo[MAX_TABELAS];
    int iter, t, g, i, inicio, fim, melhor;
    int n_grupos = (total + TAM_GRUPO - 1) / TAM_GRUPO;

    for (iter = 0; iter < ITERACOES; iter++) {
        /* 1. cada grupo escolhe a sua tabela */
        for (g = 0; g < n_grupos; g++) {
            melhor = g * n_tabelas / n_grupos;
            if (iter > 0) {
                inicio = g * TAM_GRUPO;
                fim = inicio + TAM_GRUPO < total ? inicio + TAM_GRUPO : total;
                for (t = 0; t < n_tabelas; t++)
                    custo[t] = dic_custo(&dic[t], simbolos, inicio, fim);
                for (t = 0; t < n_tabelas; t++)
                    if (custo[t] < custo[melhor])
                        melhor = t;
            }
            seletores[g] = (unsigned char) melhor;
        }

        /* 2. cada tabela conta os simbolos dos grupos que a escolheram */
        for (t = 0; t < n_tabelas; t++)
            dic_inicia(&dic[t], alfabeto);
        for (i = 0; i < total; i++)
            dic_conta(&dic[seletores[i / TAM_GRUPO]], simbolos[i]);
        for (t = 0; t < n_tabelas; t++)
            dic_gera_codigos(&dic[t]);
    }
}

unsigned long bloco_codifica(const unsigned char *bwt, int n, unsigned short *simbolos,
                             unsigned char *saida)
{
    Dicionario dic[MAX_TABELAS];
    unsigned char usado[256], ordem[MAX_TABELAS];
    FluxoBits fb;
    int i, j, t, g, alfabeto = 2, total, n_tabelas, n_grupos;

    /* mapa dos bytes presentes no bloco */
    for (i = 0; i < 256; i++)
        usado[i] = 0;
    for (i = 0; i < n; i++)
        usado[bwt[i]] = 1;
    for (i = 0; i < 256; i++)
        alfabeto += usado[i];  /* RUNA, RUNB, posicoes MTF 1..n_usados-1 e FIM */

    total = mtf_codifica(bwt, n, usado, simbolos);
    n_tabelas = 2 + total / 800;
    if (n_tabelas > MAX_TABELAS)
        n_tabelas = MAX_TABELAS;
    n_grupos = (total + TAM_GRUPO - 1) / TAM_GRUPO;
    otimiza_tabelas(simbolos, total, alfabeto, n_tabelas, dic);

    bits_inicia(&fb, saida, (unsigned long) n);
    for (i = 0; i < 256; i++)
        bits_escreve(&fb, usado[i], 1);

    /* tabela de cada grupo: sua posicao em uma lista MTF, em unario */
    bits_escreve(&fb, (unsigned long) n_tabelas, 3);
    bits_escreve(&fb, (unsigned long) n_grupos, 24);
    for (t = 0; t < n_tabelas; t++)
        ordem[t] = (unsigned char) t;
    for (g = 0; g < n_grupos; g++) {
        for (j = 0; ordem[j] != seletores[g]; j++)
            bits_escreve(&fb, 1, 1);
        bits_escreve(&fb, 0, 1);
        move(ordem, j, 0);
    }

    /* cada dicionario grava os comprimentos dos seus codigos */
    for (t = 0; t < n_tabelas; t++)
        dic_grava(&dic[t], &fb);

    for (i = 0; i < total; i++)
        dic_codifica(&dic[seletores[i / TAM_GRUPO]], &fb, simbolos[i]);
    return bits_bytes(&fb) <= (unsigned long) n ? bits_bytes(&fb) : 0;
}

/* ---------------------------------------------------------------------- */
/* Decodificacao                                                          */
/* ---------------------------------------------------------------------- */

int bloco_decodifica(unsigned char *entrada, unsigned long tamanho, unsigned char *bwt, int n)
{
    Dicionario dic[MAX_TABELAS];
    unsigned char lista[256], ordem[MAX_TABELAS];
    FluxoBits fb;
    int i, j, t, simbolo, n_usados = 0, alfabeto, n_tabelas, n_grupos;
    int saida = 0, repetiu = 0;
    long zeros = 0, peso = 1;

    /* lista MTF inicial: os bytes usados, em ordem crescente */
    bits_inicia(&fb, entrada, tamanho);
    for (i = 0; i < 256; i++)
        if (bits_le(&fb, 1))
            lista[n_usados++] = (unsigned char) i;
    alfabeto = n_usados + 2;

    n_tabelas = (int) bits_le(&fb, 3);
    n_grupos = (int) bits_le(&fb, 24);
    if (n_usados == 0 || n_tabelas < 2 || n_tabelas > MAX_TABELAS
        || n_grupos < 1 || n_grupos > n / TAM_GRUPO + 1)
        return 0;
    for (t = 0; t < n_tabelas; t++)
        ordem[t] = (unsigned char) t;
    for (i = 0; i < n_grupos; i++) {
        j = 0;
        while (bits_le(&fb, 1))
            if (++j >= n_tabelas)
                return 0;
        seletores[i] = move(ordem, j, 0);
    }

    for (t = 0; t < n_tabelas; t++)
        if (!dic_le(&dic[t], &fb, alfabeto))
            return 0;

    /* Huffman -> sequencias de zeros -> MTF-2 inversa, direto na BWT */
    for (i = 0; i < n_grupos * TAM_GRUPO; i++) {
        simbolo = dic_decodifica(&dic[seletores[i / TAM_GRUPO]], &fb);
        if (simbolo < 0)
            return 0;
        if (simbolo == RUNA || simbolo == RUNB) {
            zeros += (simbolo + 1) * peso;
            peso *= 2;
            if (zeros > n - saida)
                return 0;
            continue;
        }

        /* fim de uma sequencia de zeros: repete o byte da frente */
        if (zeros > 0) {
            for (; zeros > 0; zeros--)
                bwt[saida++] = lista[0];
            peso = 1;
            repetiu = 1;
        }
        if (simbolo == alfabeto - 1)  /* FIM */
            return saida == n && bits_bytes(&fb) <= tamanho;
        if (saida == n)
            return 0;
        bwt[saida++] = move(lista, simbolo - 1, destino_mtf2(simbolo - 1, repetiu));
        repetiu = 0;
    }
    return 0;  /* os grupos acabaram sem o simbolo FIM */
}
