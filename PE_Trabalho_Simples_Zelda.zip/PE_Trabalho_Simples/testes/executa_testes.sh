#!/bin/sh
# executa_testes.sh - Testes de desempenho do UFABC BWZip.
#
# Gera os arquivos dos tres cenarios de redundancia (baixa, media e alta),
# comprime, verifica (CRC-32) e descomprime cada um pelo menu do programa,
# confere com 'cmp' se o arquivo restaurado e identico ao original e compara
# com o gzip -9.
#
# Uso, na pasta PE_Trabalho:
#   sh testes/executa_testes.sh [arquivos extras ...]
# Arquivos extras (por exemplo, um livro em .txt ou uma foto .jpg) entram
# na mesma tabela. Os tempos do bwzip sao os que o proprio programa mostra.

set -e
cd "$(dirname "$0")/.."

gcc -std=c89 -pedantic -Wall -Wextra -O2 -o bwzip *.c
gcc -std=c89 -pedantic -Wall -Wextra -O2 -o testes/gera_testes testes/gera_testes.c

DADOS=testes/arquivos
SAIDA=testes/resultados
mkdir -p "$DADOS"
rm -rf "$SAIDA"
mkdir -p "$SAIDA"
./testes/gera_testes "$DADOS"
echo

agora() {
    date +%s.%N
}

printf '%-24s %10s | %10s %6s %7s %7s %4s %4s | %10s %6s %7s\n' \
       Arquivo Original bwzip R comp desc crc cmp "gzip -9" R comp
for f in "$DADOS"/* "$@"; do
    nome=$(basename "$f")
    cp "$f" "$SAIDA/$nome"
    entrada="$SAIDA/$nome"
    bwz="$SAIDA/${nome%.*}.bwz"
    restaurado="$SAIDA/$nome.restaurado"

    log=$(printf '1\n%s\n0\n' "$entrada" | ./bwzip)
    tc=$(echo "$log" | sed -n 's/^Tempo de compressao: *\([0-9.]*\).*/\1/p')
    log=$(printf '3\n%s\n0\n' "$bwz" | ./bwzip)
    if echo "$log" | grep -q '^Resultado: arquivo integro'; then crc=OK; else crc=FALHA; fi
    log=$(printf '2\n%s\n%s\n0\n' "$bwz" "$restaurado" | ./bwzip)
    td=$(echo "$log" | sed -n 's/^Tempo de descompressao: *\([0-9.]*\).*/\1/p')
    if cmp -s "$f" "$restaurado"; then ok=OK; else ok=FALHA; fi

    t0=$(agora)
    gzip -9 -c "$f" > "$SAIDA/$nome.gz"
    t1=$(agora)

    so=$(wc -c < "$f")
    sc=$(wc -c < "$bwz")
    sg=$(wc -c < "$SAIDA/$nome.gz")
    awk -v n="$nome" -v so="$so" -v sc="$sc" -v tc="$tc" -v td="$td" -v ok="$ok" \
        -v crc="$crc" -v sg="$sg" -v t0="$t0" -v t1="$t1" 'BEGIN {
        printf "%-24s %10d | %10d %6.3f %6.2fs %6.2fs %4s %4s | %10d %6.3f %6.2fs\n",
               n, so, sc, sc / so, tc, td, crc, ok, sg, sg / so, t1 - t0 }'
done
echo
echo "R = tamanho comprimido / tamanho original. Tempos do bwzip medidos com clock()"
echo "(tempo de CPU no Linux); tempo do gzip medido como tempo decorrido."
