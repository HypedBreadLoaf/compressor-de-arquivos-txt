/*
 * sistema.c - Funcoes que dependem do sistema operacional.
 *
 * A parte especifica do Windows fica entre "#ifdef _WIN32" e "#else"; nos
 * demais sistemas sao usadas apenas funcoes da biblioteca padrao de C.
 */
#include <stdio.h>
#include <stdlib.h>
#include "sistema.h"

#ifdef _WIN32
#include <wchar.h>
#include <windows.h>
#endif

#define TAM_LARGO 1024  /* caracteres de um caminho em UTF-16 (Windows) */

/* Le uma linha com fgets. Usada fora do Windows e quando a entrada vem de
   um arquivo ou de outro programa, e nao do teclado. */
static int le_linha_padrao(char *s, int tamanho)
{
    int n = 0, c;

    if (fgets(s, tamanho, stdin) == NULL)
        return 0;
    while (s[n] != '\0')
        n++;
    if (n > 0 && s[n - 1] == '\n')
        s[--n] = '\0';
    else  /* linha longa demais: descarta o resto */
        while ((c = getchar()) != '\n' && c != EOF)
            ;
    if (n > 0 && s[n - 1] == '\r')
        s[--n] = '\0';
    return 1;
}

int sistema_inicio_nome(const char *caminho)
{
    int i, inicio = 0;

    for (i = 0; caminho[i] != '\0'; i++)
        if (caminho[i] == '/' || caminho[i] == '\\' || (caminho[i] == ':' && i == 1))
            inicio = i + 1;
    return inicio;
}

#ifdef _WIN32

static UINT pagina_original = 0;

static void restaura_terminal(void)
{
    SetConsoleOutputCP(pagina_original);
}

void sistema_inicia(void)
{
    /* o terminal passa a interpretar como UTF-8 o que o programa escreve;
       GetConsoleOutputCP retorna 0 se o programa nao tiver terminal */
    pagina_original = GetConsoleOutputCP();
    if (pagina_original != 0 && SetConsoleOutputCP(CP_UTF8))
        atexit(restaura_terminal);
}

/* Converte de UTF-8 para UTF-16. Retorna 0 se o texto nao for UTF-8
   valido ou nao couber em 'tamanho' caracteres. */
static int para_utf16(const char *s, wchar_t *w, int tamanho)
{
    return MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, s, -1, w, tamanho) > 0;
}

int sistema_le_linha(char *s, int tamanho)
{
    HANDLE teclado = GetStdHandle(STD_INPUT_HANDLE);
    wchar_t linha[TAM_LARGO], lidos[256];
    DWORD modo, n_lidos, i;
    int n = 0, fim = 0;

    if (teclado == INVALID_HANDLE_VALUE || !GetConsoleMode(teclado, &modo))
        return le_linha_padrao(s, tamanho);

    /* le o teclado em UTF-16 ate o Enter, guardando o que couber */
    while (!fim) {
        if (!ReadConsoleW(teclado, lidos, 256, &n_lidos, NULL) || n_lidos == 0)
            return 0;
        for (i = 0; i < n_lidos && !fim; i++) {
            if (lidos[i] == L'\n')
                fim = 1;
            else if (lidos[i] == 0x1A && n == 0)  /* Ctrl+Z: fim da entrada */
                return 0;
            else if (lidos[i] != L'\r' && n < TAM_LARGO - 1)
                linha[n++] = lidos[i];
        }
    }
    linha[n] = L'\0';
    if (WideCharToMultiByte(CP_UTF8, 0, linha, -1, s, tamanho, NULL, NULL) == 0)
        s[0] = '\0';  /* nao coube em 'tamanho' bytes */
    return 1;
}

FILE *sistema_abre(const char *caminho, const char *modo)
{
    wchar_t wcaminho[TAM_LARGO], wmodo[8];

    if (para_utf16(caminho, wcaminho, TAM_LARGO) && para_utf16(modo, wmodo, 8))
        return _wfopen(wcaminho, wmodo);
    return fopen(caminho, modo);  /* nao e UTF-8: usa a codificacao do Windows */
}

int sistema_apaga(const char *caminho)
{
    wchar_t wcaminho[TAM_LARGO];

    if (para_utf16(caminho, wcaminho, TAM_LARGO))
        return _wremove(wcaminho);
    return remove(caminho);
}

#else

void sistema_inicia(void)
{
}

int sistema_le_linha(char *s, int tamanho)
{
    return le_linha_padrao(s, tamanho);
}

FILE *sistema_abre(const char *caminho, const char *modo)
{
    return fopen(caminho, modo);
}

int sistema_apaga(const char *caminho)
{
    return remove(caminho);
}

#endif
