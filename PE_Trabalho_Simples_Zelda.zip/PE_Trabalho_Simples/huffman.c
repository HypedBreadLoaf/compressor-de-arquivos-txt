/*
 * huffman.c - TAD Arvore de Codificacao de Huffman.
 */
#include "huffman.h"

/* No da arvore. As folhas ocupam os indices 0..n-1 e os nos internos
   n..2n-2, criados em ordem crescente: o pai sempre tem indice maior que os
   filhos e a raiz e o ultimo no. */
typedef struct {
    unsigned long peso;
    int pai;
    int profundidade;
} NoHuffman;

/* Fila de prioridades minima (heap binario) com indices de nos: desce o
   elemento da posicao i ate restaurar a ordem do heap */
static void desce(int *heap, int tam, int i, const NoHuffman *nos)
{
    int filho, no = heap[i];

    while ((filho = 2 * i + 1) < tam) {
        if (filho + 1 < tam && nos[heap[filho + 1]].peso < nos[heap[filho]].peso)
            filho++;
        if (nos[no].peso <= nos[heap[filho]].peso)
            break;
        heap[i] = heap[filho];
        i = filho;
    }
    heap[i] = no;
}

/* Constroi a arvore de Huffman e retorna a profundidade da folha mais funda */
static int constroi_arvore(NoHuffman *nos, int n)
{
    int heap[HUF_MAX_SIMBOLOS];
    int i, a, b, tam, novo, maior = 0;

    for (i = 0; i < n; i++)
        heap[i] = i;
    for (i = n / 2 - 1; i >= 0; i--)
        desce(heap, n, i, nos);

    /* une os dois nos mais leves; o novo no ocupa o topo do heap */
    for (tam = n, novo = n; tam > 1; novo++) {
        a = heap[0];
        heap[0] = heap[--tam];
        desce(heap, tam, 0, nos);
        b = heap[0];
        nos[novo].peso = nos[a].peso + nos[b].peso;
        nos[a].pai = novo;
        nos[b].pai = novo;
        heap[0] = novo;
        desce(heap, tam, 0, nos);
    }

    /* profundidades, da raiz para as folhas */
    nos[novo - 1].profundidade = 0;
    for (i = novo - 2; i >= 0; i--) {
        nos[i].profundidade = nos[nos[i].pai].profundidade + 1;
        if (nos[i].profundidade > maior)
            maior = nos[i].profundidade;
    }
    return maior;
}

void huf_comprimentos(const unsigned long *freq, int n, unsigned char *comp)
{
    NoHuffman nos[2 * HUF_MAX_SIMBOLOS];
    int i;

    for (i = 0; i < n; i++)
        nos[i].peso = freq[i] > 0 ? freq[i] : 1;

    /* se algum codigo passar do limite, achata as frequencias e reconstroi */
    while (constroi_arvore(nos, n) > HUF_MAX_COMPRIMENTO)
        for (i = 0; i < n; i++)
            nos[i].peso = 1 + nos[i].peso / 2;

    for (i = 0; i < n; i++)
        comp[i] = (unsigned char) nos[i].profundidade;
}

void huf_codigos(const unsigned char *comp, int n, unsigned int *codigos)
{
    unsigned int codigo = 0;
    int c, s;

    for (c = 1; c <= HUF_MAX_COMPRIMENTO; c++) {
        for (s = 0; s < n; s++)
            if (comp[s] == c)
                codigos[s] = codigo++;
        codigo <<= 1;
    }
}

void huf_prepara(DecodificadorHuffman *d, const unsigned char *comp, int n)
{
    int c, s, k = 0;

    for (c = 0; c <= HUF_MAX_COMPRIMENTO; c++)
        d->contagem[c] = 0;
    for (s = 0; s < n; s++)
        d->contagem[comp[s]]++;
    for (c = 1; c <= HUF_MAX_COMPRIMENTO; c++)
        for (s = 0; s < n; s++)
            if (comp[s] == c)
                d->simbolos[k++] = s;
}

/* Le um bit por vez. 'primeiro' e o primeiro codigo canonico com o
   comprimento atual; os codigos desse comprimento vao de 'primeiro' a
   'primeiro' + contagem - 1. */
int huf_decodifica(const DecodificadorHuffman *d, FluxoBits *fb)
{
    int c, codigo = 0, primeiro = 0, indice = 0;

    for (c = 1; c <= HUF_MAX_COMPRIMENTO; c++) {
        codigo = (codigo << 1) | (int) bits_le(fb, 1);
        if (codigo - primeiro < d->contagem[c])
            return d->simbolos[indice + codigo - primeiro];
        indice += d->contagem[c];
        primeiro = (primeiro + d->contagem[c]) << 1;
    }
    return -1;
}
