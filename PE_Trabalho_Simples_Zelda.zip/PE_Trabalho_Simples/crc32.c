/*
 * crc32.c - Codigo de verificacao CRC-32.
 *
 * Os dados sao tratados como um polinomio com coeficientes 0 e 1, dividido
 * pelo polinomio gerador do padrao IEEE 802.3; o CRC e o resto da divisao.
 * Em vez de dividir bit a bit, usa-se uma tabela com o efeito de cada um dos
 * 256 valores de byte, calculada uma unica vez: cada byte custa uma consulta
 * a tabela, um XOR e um deslocamento.
 */
#include "crc32.h"

/* Polinomio gerador 0x04C11DB7 com os bits invertidos, pois os bits de cada
   byte sao processados do menos para o mais significativo */
#define POLINOMIO 0xEDB88320UL
#define MASCARA 0xFFFFFFFFUL

static unsigned long tabela[256];
static int tabela_pronta = 0;

static void monta_tabela(void)
{
    unsigned long resto;
    int i, bit;

    for (i = 0; i < 256; i++) {
        resto = (unsigned long) i;
        for (bit = 0; bit < 8; bit++)
            resto = (resto & 1) ? (resto >> 1) ^ POLINOMIO : resto >> 1;
        tabela[i] = resto;
    }
    tabela_pronta = 1;
}

unsigned long crc32_atualiza(unsigned long crc, const unsigned char *dados, unsigned long n)
{
    unsigned long i;

    if (!tabela_pronta)
        monta_tabela();
    /* o padrao inverte todos os bits no inicio e no fim */
    crc = ~crc & MASCARA;
    for (i = 0; i < n; i++)
        crc = tabela[(crc ^ dados[i]) & 0xFF] ^ (crc >> 8);
    return ~crc & MASCARA;
}
