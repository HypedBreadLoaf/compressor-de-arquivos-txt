/*
 * compressor.h - Compressao, descompressao e verificacao de arquivos .bwz.
 *
 * As funcoes retornam NULL em caso de sucesso ou uma mensagem de erro e
 * preenchem 'info'. Se houver erro, o arquivo de saida incompleto e apagado.
 */
#ifndef COMPRESSOR_H
#define COMPRESSOR_H

#define BWZ_TAM_NOME 1024  /* maior nome de arquivo guardado no .bwz, com o '\0' */

typedef struct {
    unsigned long original;    /* tamanho do arquivo original, em bytes */
    unsigned long comprimido;  /* tamanho do arquivo .bwz, em bytes */
    unsigned long blocos;      /* blocos processados com sucesso */
    unsigned long crc;         /* CRC-32 do arquivo original */
    char nome[BWZ_TAM_NOME];   /* nome do arquivo original, sem a pasta */
} InfoBwz;

const char *comprime(const char *nome_entrada, const char *nome_saida, InfoBwz *info);

/* Restaura o arquivo original, conferindo o CRC-32 de cada bloco */
const char *descomprime(const char *nome_entrada, const char *nome_saida, InfoBwz *info);

/* Descomprime na memoria, sem gravar nada, so para conferir os CRC-32 */
const char *verifica(const char *nome_entrada, InfoBwz *info);

/* Le apenas o cabecalho do .bwz (para obter o nome original) */
const char *le_cabecalho(const char *nome_entrada, InfoBwz *info);

#endif
