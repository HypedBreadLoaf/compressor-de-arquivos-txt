/*
 * bwt.h - Transformada de Burrows-Wheeler (BWT).
 *
 * A BWT reordena o bloco de modo que caracteres seguidos por contextos
 * parecidos fiquem proximos, formando longas sequencias de simbolos
 * repetidos, que sao muito mais faceis de comprimir.
 *
 * Considera-se um sentinela virtual, menor que qualquer byte, no fim do
 * texto. A BWT tem n+1 linhas; o sentinela nao e gravado e a linha em que
 * ele estaria e o "indice primario".
 */
#ifndef BWT_H
#define BWT_H

/* Grava em 'bwt' a BWT dos n bytes de 'texto', usando 'sa' (n inteiros)
   para o vetor de sufixos. Retorna o indice primario (de 1 a n), ou -1 se
   faltar memoria. */
int bwt_direta(const unsigned char *texto, int n, int *sa, unsigned char *bwt);

/* Desfaz a BWT: 'bloco' contem a BWT e e sobrescrito com o texto original.
   'psi' e uma area de trabalho com n+1 posicoes. */
void bwt_inversa(unsigned char *bloco, int n, int primario, unsigned int *psi);

#endif
