/*
 * sistema.h - Funcoes que dependem do sistema operacional: leitura do
 * teclado, abertura de arquivos e nomes de caminhos.
 *
 * Em todo o programa, os caminhos sao texto em UTF-8. No Windows, o terminal
 * entrega o texto digitado em outra codificacao (pagina de codigo 850) e o
 * fopen espera uma terceira (pagina 1252), entao caminhos com letras
 * acentuadas ou cedilha nao eram encontrados.
 * Por isso, no Windows, este modulo le o teclado e abre os arquivos pelas
 * funcoes Unicode do sistema (ReadConsoleW e _wfopen), convertendo de e para
 * UTF-8. Nos demais sistemas, usa apenas a biblioteca padrao.
 */
#ifndef SISTEMA_H
#define SISTEMA_H

#include <stdio.h>

/* Prepara o terminal para mostrar caminhos com acentos. Chamar no inicio
   do programa; a configuracao original do terminal e restaurada no fim. */
void sistema_inicia(void);

/* Le uma linha do teclado (sem o '\n') em UTF-8, com ate tamanho-1 bytes;
   o excesso de uma linha longa e descartado. Retorna 0 no fim da entrada. */
int sistema_le_linha(char *s, int tamanho);

/* Equivalentes a fopen e remove, aceitando caminhos com acentos */
FILE *sistema_abre(const char *caminho, const char *modo);
int sistema_apaga(const char *caminho);

/* Posicao em que comeca o nome do arquivo no caminho, depois da ultima
   barra ('/' ou '\') ou da letra da unidade ("C:") */
int sistema_inicio_nome(const char *caminho);

#endif
