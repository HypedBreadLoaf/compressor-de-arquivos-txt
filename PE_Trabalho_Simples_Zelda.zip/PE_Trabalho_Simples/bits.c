/*
 * bits.c - Leitura e escrita de sequencias de bits em um buffer na memoria.
 */
#include "bits.h"

void bits_inicia(FluxoBits *fb, unsigned char *dados, unsigned long tamanho)
{
    fb->dados = dados;
    fb->tamanho = tamanho;
    fb->pos = 0;
}

void bits_escreve(FluxoBits *fb, unsigned long valor, int n)
{
    unsigned long byte;

    for (n--; n >= 0; n--, fb->pos++) {
        byte = fb->pos / 8;
        if (byte >= fb->tamanho)
            continue;
        if (fb->pos % 8 == 0)
            fb->dados[byte] = 0;
        if ((valor >> n) & 1)
            fb->dados[byte] |= (unsigned char) (0x80 >> (fb->pos % 8));
    }
}

unsigned long bits_le(FluxoBits *fb, int n)
{
    unsigned long valor = 0, byte;

    for (; n > 0; n--, fb->pos++) {
        byte = fb->pos / 8;
        valor <<= 1;
        if (byte < fb->tamanho)
            valor |= (fb->dados[byte] >> (7 - fb->pos % 8)) & 1;
    }
    return valor;
}

unsigned long bits_bytes(const FluxoBits *fb)
{
    return (fb->pos + 7) / 8;
}
