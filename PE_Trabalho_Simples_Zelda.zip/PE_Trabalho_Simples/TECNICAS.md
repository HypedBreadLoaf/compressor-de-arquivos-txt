# Técnicas usadas no UFABC BWZip

Este documento explica, em linguagem simples, cada técnica usada no programa e onde ela está no código. A ideia é que qualquer integrante do grupo consiga explicar qualquer parte do trabalho na apresentação.

---

## Visão geral

O BWZip comprime um arquivo em quatro etapas, aplicadas a cada **bloco** de até 8 MiB:

```
COMPRIMIR
arquivo ─► blocos ─► BWT ─► MTF-2 ─► sequências de zeros ─► Huffman ─► arquivo .bwz
                     (agrupa    (troca letras   (resume         (códigos curtos
                      letras     por números     zeros            para o que
                      iguais)    pequenos)       repetidos)       é frequente)

DESCOMPRIMIR: o mesmo caminho ao contrário e, no fim, confere o CRC-32.
```

Nenhuma etapa sozinha comprime muito. A **BWT** e o **MTF** só *reorganizam* os dados para que o **Huffman** consiga comprimir bem. Essa é a mesma família de algoritmos do `bzip2`.

| Arquivo | O que faz |
|---|---|
| `main.c` | Menu, nomes dos arquivos e exibição dos resultados |
| `compressor.c` | Lê e grava o arquivo em blocos; define o formato `.bwz` |
| `bwt.c` | Transformada de Burrows-Wheeler (direta e inversa) e vetor de sufixos (SA-IS) |
| `bloco.c` | MTF-2, sequências de zeros e Huffman com várias tabelas |
| `dicionario.c` | **TAD Dicionário**: símbolo → frequência e código |
| `huffman.c` | **TAD Árvore de Huffman**: comprimentos e códigos canônicos |
| `bits.c` | **TAD FluxoBits**: grava e lê bit a bit |
| `crc32.c` | Código de verificação CRC-32 |
| `sistema.c` | Teclado e arquivos com acentos no Windows |

---

## 1. Divisão em blocos

O arquivo é lido em pedaços de até **8 MiB** (`BLOCO_MAXIMO`, em `bloco.h`), e cada bloco é comprimido de forma independente.

- **Por quê?** A BWT precisa do bloco inteiro na memória. Blocos maiores comprimem melhor, mas gastam mais memória. Com 8 MiB, a compressão usa cerca de 48 MiB.
- Arquivos menores que 8 MiB usam um único bloco do tamanho exato do arquivo, para não alocar memória à toa.

---

## 2. Transformada de Burrows-Wheeler (BWT) — `bwt.c`

**Ideia:** reordenar as letras do bloco de modo que letras iguais fiquem juntas, mas de um jeito que dê para **desfazer**.

**Como funciona (exemplo com "banana"):** acrescenta-se ao fim um símbolo especial `$`, menor que qualquer letra (o *sentinela*). Escrevem-se todas as rotações do texto e elas são ordenadas em ordem alfabética. A BWT é a **última coluna**:

| Linha | Rotação ordenada | Última letra |
|---|---|---|
| 0 | `$banana` | a |
| 1 | `a$banan` | n |
| 2 | `ana$ban` | n |
| 3 | `anana$b` | b |
| 4 | `banana$` | **$** ← índice primário |
| 5 | `na$bana` | a |
| 6 | `nana$ba` | a |

A BWT de "banana" é `annbaa` (sem o `$`), com **índice primário 4**, que é a linha onde o `$` estaria. O programa grava os dois.

**Por que agrupa letras iguais?** Cada linha começa com o *contexto* que vem depois da letra da última coluna. Em português, o que vem antes de "ue " quase sempre é "q", e o que vem antes de "ção" quase sempre é "a". Contextos parecidos ficam vizinhos na ordenação, então as letras anteriores a eles também ficam juntas: `qqqqqq`, `aaaaa`...

**Sentinela virtual:** o `$` nunca é gravado de verdade. O código apenas *considera* que existe um símbolo menor que todos no fim do bloco. Assim, todos os 256 valores de byte continuam livres para os dados.

---

## 3. Vetor de sufixos e o algoritmo SA-IS — `bwt.c`

Ordenar as rotações é o mesmo que ordenar os **sufixos** do texto (o pedaço que vai de uma posição até o fim):

```
"banana" → sufixos: banana(0) anana(1) nana(2) ana(3) na(4) a(5)
em ordem:            a(5) ana(3) anana(1) banana(0) na(4) nana(2)
vetor de sufixos:    [5, 3, 1, 0, 4, 2]
```

A BWT é a letra que vem **antes** de cada sufixo, nessa ordem.

**Problema:** ordenar comparando sufixos é lento. Num arquivo com 8 milhões de letras "a", cada comparação percorre milhões de letras. Além disso, o trabalho proíbe rotinas prontas de ordenação (`qsort`).

**Solução: SA-IS** (Nong, Zhang e Chan, 2009). Ele monta o vetor de sufixos em tempo **linear, O(n)**. A ideia central é uma dedução simples:

> Se dois sufixos começam com a mesma letra, a ordem entre eles é a mesma ordem dos sufixos que começam uma posição depois.

Os passos são:

1. **Classifica** cada sufixo como **S** (menor que o sufixo seguinte) ou **L** (maior). Isso é feito numa única passada, do fim para o começo.
2. Os sufixos **LMS** (tipo S logo depois de um tipo L) funcionam como "pontos de apoio". Se eles estiverem ordenados, a posição de **todos os outros é deduzida** em duas varreduras: os do tipo L da esquerda para a direita e os do tipo S da direita para a esquerda. Isso se chama *ordenação induzida*.
3. Para ordenar os LMS, cada trecho entre dois LMS recebe um "nome" (um número). Se houver nomes repetidos, o algoritmo **chama a si mesmo** (recursão) com o texto dos nomes, que tem no máximo metade do tamanho.

Os tipos S/L ocupam **1 bit por posição** (vetor de bits `tipos`), e o texto reduzido da recursão reaproveita o próprio vetor `sa`, sem alocar outro.

---

## 4. BWT inversa — `bwt.c`

Para desfazer a BWT só se conhece a última coluna (L). A primeira coluna (F) é fácil de obter: são as mesmas letras **em ordem**, conseguidas por contagem.

O truque é que **a k-ésima letra "a" da coluna L é a mesma letra que a k-ésima "a" da coluna F**. Ligando cada letra de F à sua posição em L, forma-se um caminho que passa pelo texto inteiro. Começando pela linha do índice primário, que é a linha do texto completo, lê-se o texto original do começo ao fim.

**Otimização:** cada posição do vetor `psi` guarda junto, em 32 bits, *a próxima linha* (24 bits) e *a letra* (8 bits): `(linha << 8) | letra`. Assim cada passo faz **um único acesso à memória**. Por isso o bloco precisa ter menos de 2²⁴ bytes (16 MiB), e o limite de 8 MiB respeita isso.

---

## 5. Move-to-Front (MTF) e a variante MTF-2 — `bloco.c`

Depois da BWT, o bloco tem muitas letras repetidas (`aaaabbbaaaa`). O MTF transforma isso em **muitos zeros**.

**MTF simples:** mantém-se uma lista com os bytes, e cada byte do bloco é trocado pela **posição** dele na lista. Depois, o byte vai para a frente.

```
lista inicial [a, b]
texto:  a a a a b a a a a
MTF:    0 0 0 0 1 1 0 0 0      (depois do b, o "a" custa 1 para voltar à frente)
```

**MTF-2** (Balkenhol, Kurtz e Shtarkov, 1999), a variante usada: um byte novo vai para a **posição 1**, e não direto para a frente. Ele só chega à frente se for usado de novo. Um byte isolado, portanto, não tira da frente o byte que está se repetindo:

```
MTF-2:  0 0 0 0 1 0 0 0 0      (um número diferente de zero a menos)
```

Na saída da BWT isso acontece o tempo todo, então o MTF-2 costuma comprimir um pouco melhor que o MTF simples.

**Dicionário dos bytes usados:** a lista começa só com os bytes que aparecem no bloco, em ordem crescente. Um mapa de 256 bits gravado no arquivo diz quais são esses bytes.

---

## 6. Sequências de zeros: RUNA e RUNB — `bloco.c`

Em vez de gravar "0 0 0 0 0 0 0", grava-se **quantos zeros** há, usando só dois símbolos: **RUNA** (vale 1) e **RUNB** (vale 2), em *base 2 bijetiva* (a mesma técnica do bzip2):

| Zeros | Grava | Conta (do dígito menos significativo para o mais) |
|---|---|---|
| 1 | A | 1 |
| 2 | B | 2 |
| 3 | A A | 1 + 1×2 |
| 4 | B A | 2 + 1×2 |
| 5 | A B | 1 + 2×2 |
| 8 | B A A | 2 + 1×2 + 1×4 |

Uma sequência de **1 milhão** de zeros vira cerca de **20 símbolos**. Como os dígitos são 1 e 2 (e não 0 e 1), todo número tem uma única representação e não é preciso gravar quantos dígitos ele tem: a sequência acaba quando aparece um símbolo que não é RUNA nem RUNB.

**Alfabeto final:** RUNA, RUNB, as posições 1, 2, 3… do MTF e um símbolo **FIM**, que marca o fim do bloco.

---

## 7. Codificação de Huffman — TAD Árvore (`huffman.c`)

**Ideia:** símbolos frequentes recebem códigos **curtos** e símbolos raros recebem códigos **longos**. Nenhum código é começo de outro (*código prefixo*), então dá para decodificar sem separadores.

**Construção da árvore:** juntam-se sempre os dois nós de **menor peso** até sobrar um só. Para achar os dois menores rapidamente, usa-se uma **fila de prioridades (heap binário)**. Exemplo real gerado pelo código:

```
frequências: A=5  B=2  C=1  D=1
junta C+D (peso 2) → junta B+CD (peso 4) → junta A+BCD (peso 9)

         (9)
        /   \
       A    (4)          A = 0      (1 bit)
           /   \         B = 10     (2 bits)
          B    (2)       C = 110    (3 bits)
              /   \      D = 111    (3 bits)
             C     D
```

Total: 5×1 + 2×2 + 1×3 + 1×3 = **15 bits**, contra 9×2 = 18 bits com códigos de tamanho fixo.

**Como a árvore é guardada:** os nós ficam num vetor, sem ponteiros nem `malloc`. Cada nó guarda o peso e o índice do pai. O comprimento do código de cada símbolo é a **profundidade** da folha.

**Limite de 17 bits:** com frequências muito desiguais, a árvore pode ficar muito funda. Se algum código passar de 17 bits, as frequências são "achatadas" (`peso = 1 + peso/2`) e a árvore é refeita. O limite deixa o decodificador simples e permite gravar os comprimentos em poucos bits.

---

## 8. Códigos canônicos — `huffman.c`

Seria caro gravar a árvore inteira no arquivo. Em vez disso, os códigos são atribuídos de forma **canônica**: em ordem de comprimento e, empatando, em ordem de símbolo. Cada código é o anterior + 1 e, quando o comprimento aumenta, ganha um 0 no fim.

Assim, **basta gravar os comprimentos** (1, 2, 3, 3 no exemplo) para que o descompressor reconstrua exatamente os mesmos códigos (0, 10, 110, 111).

Os comprimentos são gravados em **delta**: o primeiro em 5 bits e, para cada símbolo seguinte, só a diferença em relação ao anterior (`10` = +1, `11` = −1, `0` = próximo símbolo). Comprimentos vizinhos costumam ser parecidos, então isso gasta poucos bits.

---

## 9. TAD Dicionário — `dicionario.h` / `dicionario.c`

O **Dicionário** guarda a relação entre cada **símbolo**, sua **frequência** e seu **código de Huffman**:

```c
typedef struct {
    int n;                                  /* quantidade de símbolos */
    unsigned long freq[HUF_MAX_SIMBOLOS];   /* frequência de cada símbolo */
    unsigned char comp[HUF_MAX_SIMBOLOS];   /* comprimento do código, em bits */
    unsigned int codigo[HUF_MAX_SIMBOLOS];  /* código canônico */
    DecodificadorHuffman dec;               /* usado só na descompressão */
} Dicionario;
```

| Operação | O que faz |
|---|---|
| `dic_inicia` | Cria um dicionário vazio para os símbolos 0..n-1 |
| `dic_conta` | Registra mais uma ocorrência de um símbolo |
| `dic_gera_codigos` | Usa o TAD Árvore para gerar os códigos |
| `dic_custo` | Diz quantos bits um trecho ocuparia com este dicionário |
| `dic_codifica` / `dic_decodifica` | Grava / lê o código de um símbolo |
| `dic_grava` / `dic_le` | Grava / reconstrói o dicionário no arquivo (só os comprimentos) |

**Endereçamento direto:** o material da disciplina usa uma *tabela hash* para mapear palavras → frequências. Aqui os símbolos já são números de 0 a 257, então **o próprio símbolo é a posição no vetor**. Funciona como uma tabela hash perfeita: busca e atualização em **O(1)**, sem colisões e sem precisar de função de hash.

Na leitura, `dic_le` confere a **desigualdade de Kraft** (a soma de 2^−comprimento de todos os códigos tem de dar exatamente 1). Isso rejeita comprimentos corrompidos antes de decodificar.

---

## 10. Várias tabelas de Huffman — `bloco.c`

Um único dicionário para o bloco inteiro desperdiça bits, porque partes diferentes do arquivo têm estatísticas diferentes. Por isso:

1. Os símbolos são divididos em **grupos de 50**.
2. Usam-se de **2 a 7 dicionários** (mais dicionários para blocos maiores: `2 + total/800`).
3. **Otimização em 4 rodadas:** na primeira, os grupos são divididos em faixas, uma por dicionário. Nas seguintes, **cada grupo escolhe o dicionário mais barato para ele** (`dic_custo`), e cada dicionário é recalculado só com os grupos que o escolheram. É a mesma ideia do agrupamento *k-means*.
4. O número do dicionário de cada grupo (o *seletor*) passa por um MTF e é gravado em **unário** (`0` = mesmo da frente, `10` = segundo da lista...). Como grupos vizinhos costumam usar o mesmo dicionário, quase todo seletor custa 1 bit.

---

## 11. Leitura e escrita de bits — TAD FluxoBits (`bits.c`)

Os códigos de Huffman têm tamanhos variáveis (1 a 17 bits), mas arquivos são gravados em bytes. O `FluxoBits` guarda um buffer e a posição do próximo bit; `bits_escreve` e `bits_le` gravam e leem qualquer quantidade de bits, do mais significativo para o menos significativo.

---

## 12. Blocos que não compensam comprimir — `compressor.c`

Dados aleatórios não têm padrão. Se o resultado comprimido não ficar menor que o original, o bloco é **guardado como está**, indicado por índice primário 0. Por isso um arquivo aleatório fica com R = 1,000, e não maior que o original.

---

## 13. Verificação de integridade: CRC-32 — `crc32.c`

**Problema:** sem verificação, um `.bwz` danificado (por exemplo, por um pendrive com defeito) era "descomprimido" sem erro, mas gerava um arquivo **errado**. Num teste com 6060 arquivos corrompidos de propósito, a versão sem CRC aceitou 3151 deles e gerou saída errada.

**Solução:** o CRC-32 é uma "impressão digital" de 32 bits dos dados. O compressor grava o CRC do original; o descompressor recalcula sobre o que restaurou e compara. Qualquer diferença indica um arquivo danificado. Com o CRC, **nenhum dos 6060 arquivos corrompidos gerou saída errada**: todos foram recusados, exceto um caso em que o bit alterado era de preenchimento (sobra do último byte) e o arquivo restaurado saiu correto.

**Como é calculado:** os bits dos dados são tratados como um polinômio, que é dividido pelo polinômio padrão do Ethernet (IEEE 802.3); o CRC é o **resto da divisão**. Para não dividir bit a bit, uma **tabela de 256 posições**, calculada uma única vez, guarda o efeito de cada byte possível. Cada byte custa uma consulta, um XOR e um deslocamento.

**Detalhes do formato:**
- Cada bloco guarda o **CRC acumulado** (do início do arquivo até o fim do bloco). Isso detecta blocos alterados, **trocados de lugar** ou **perdidos**, e diz **em qual bloco** está o problema.
- O **cabeçalho tem o seu próprio CRC**, que protege o nome original guardado nele.
- Uma **marca de fim** (bloco de tamanho 0) detecta um arquivo cortado no meio.
- O CRC é conferido **antes** de gravar cada bloco, então dados errados nunca chegam ao arquivo restaurado. Em caso de erro, o arquivo incompleto é apagado.

**Para demonstrar:** o valor mostrado pelo programa é o CRC-32 padrão, o mesmo do zip, gzip e PNG. No Windows, com o 7-Zip instalado: botão direito no arquivo original → **7-Zip → CRC SHA → CRC-32**. O número tem de ser igual ao que o BWZip mostra.

> O CRC detecta erros **acidentais**. Ele não protege contra alguém que altere o arquivo de propósito e recalcule o CRC; para isso existem resumos criptográficos, como o SHA-256.

**Opção 3 do menu (Verificar integridade):** descomprime tudo **na memória**, sem gravar nada, e confere todos os CRC.

---

## 14. Formato do arquivo `.bwz`

Inteiros em *little-endian* (byte menos significativo primeiro):

| Parte | Conteúdo |
|---|---|
| Cabeçalho | `"BWZ2"` · tamanho máximo de bloco (4 bytes) · tamanho do nome (2) · **nome original** · CRC-32 do cabeçalho (4) |
| Cada bloco | tamanho n (4) · **CRC-32 acumulado** (4) · índice primário (4) · dados |
| ↳ se índice primário = 0 | os n bytes originais (bloco guardado sem compressão) |
| ↳ senão | tamanho codificado (4) · bits do bloco (mapa de bytes, dicionários, seletores e códigos) |
| Fim | n = 0 (4) |

---

## 15. Uso eficiente da memória — `compressor.c`

- Os buffers são alocados **uma única vez por arquivo** e reaproveitados em todos os blocos.
- **Reaproveitamento de áreas:** os símbolos do MTF (`unsigned short`) são gravados na memória do vetor de sufixos (`int`), que não é mais necessário nesse ponto. Os bits comprimidos são gravados no mesmo buffer da BWT, que já foi lido. Na descompressão, os bits lidos do arquivo ficam no buffer `psi`, que só é usado depois.
- Total: cerca de **6n bytes** na compressão (48 MiB para 8 MiB) e **5n bytes** na descompressão.
- Tudo o que é alocado é liberado, inclusive nos caminhos de erro. Isso foi verificado com o *AddressSanitizer*, que não encontrou vazamentos nem acessos inválidos.

---

## 16. Nomes de arquivos — `main.c`

- **Nunca sobrescreve:** se o nome de saída já existe, usa `nome_1`, `nome_2`...
- **Nome original guardado:** o `.bwz` guarda o nome do arquivo original (sem a pasta). Na descompressão:
  - **Enter** → restaura com o nome original, na pasta do `.bwz`;
  - uma **pasta** (`C:\saida\`) → nome original, nessa pasta;
  - um **nome sem extensão** → a extensão original é acrescentada (`relatorio` → `relatorio.txt`).
- Por segurança, um nome guardado com `\`, `/` ou `:` é limpo, para que um `.bwz` malicioso não consiga gravar em outra pasta.

---

## 17. Caminhos com acentos no Windows — `sistema.c`

**Problema:** no Windows, o terminal entrega o texto digitado numa codificação (página **850**, onde `ç` = 0x87) e o `fopen` espera outra (página **1252**, onde `ç` = 0xE7). Um caminho como `Correção\relatório.txt` não era encontrado.

**Solução:** todo o programa trata os caminhos como **UTF-8**. Só o módulo `sistema.c` conversa com o Windows:
- lê o teclado com `ReadConsoleW` (Unicode) e converte para UTF-8;
- abre e apaga arquivos com `_wfopen` / `_wremove` (Unicode);
- coloca o terminal em UTF-8 para mostrar os acentos corretamente e **restaura a configuração original** quando o programa termina.

Fora do Windows, o mesmo módulo usa apenas `fopen` e `fgets`. Toda a parte específica do Windows fica isolada entre `#ifdef _WIN32` e `#else`, e o resto do código é C ANSI puro.

---

## 18. Resultados (arquivos de 10 MiB)

| Cenário | BWZip R | gzip -9 R | bzip2 -9 R | BWZip comprime / descomprime |
|---|---|---|---|---|
| Alta redundância (log de servidor) | **0,028** | 0,045 | 0,027 | 0,32 s / 0,23 s |
| Média redundância (áudio WAV) | **0,523** | 0,790 | 0,567 | 1,01 s / 0,45 s |
| Baixa redundância (aleatório) | 1,000 | 1,000 | 1,004 | 1,48 s / 0,02 s |

R = tamanho comprimido ÷ tamanho original (menor é melhor). Os tempos variam conforme o computador.

- O BWZip **supera o gzip** nos três cenários, porque a BWT aproveita contextos longos, enquanto o gzip (LZ77) só procura repetições numa janela de 32 KB.
- O gzip é **mais rápido**: ordenar os sufixos custa mais que procurar repetições.
- Fica **próximo do bzip2** (mesma família) e até o supera no WAV, provavelmente pelos blocos maiores (8 MiB, contra 900 KB do `bzip2 -9`) e pelo MTF-2.
- Dados aleatórios não comprimem com nenhum método; o BWZip apenas não aumenta o arquivo.

---

## 19. Perguntas que podem aparecer na arguição

**Por que BWT + Huffman, e não LZ como o gzip?**
O enunciado permite escolher o algoritmo, e o Huffman, que é um dos algoritmos citados, está presente. A BWT agrupa símbolos pelo contexto, e o resultado comprime melhor que o gzip nos três cenários testados.

**Por que a BWT é reversível, se ela embaralha o texto?**
Porque a k-ésima ocorrência de uma letra na última coluna corresponde à k-ésima na primeira coluna. Seguindo essas ligações a partir do índice primário, o texto é refeito (seção 4).

**Por que não usar `qsort` para ordenar os sufixos?**
O enunciado proíbe rotinas prontas de ordenação. Além disso, comparar sufixos de um arquivo muito repetitivo levaria horas; o SA-IS é linear.

**O que é o sentinela e por que ele é "virtual"?**
É um símbolo menor que todos, no fim do bloco, que garante que nenhum sufixo seja começo de outro. Ele não é gravado; o código apenas considera que ele existe, para não "gastar" um dos 256 valores de byte.

**Por que gravar só os comprimentos dos códigos?**
Porque os códigos são canônicos: dados os comprimentos, só existe uma forma de atribuí-los (seção 8).

**Por que limitar os códigos a 17 bits?**
Para que o decodificador e a gravação dos comprimentos sejam simples e de tamanho fixo. A perda de compressão é desprezível.

**Por que várias tabelas de Huffman?**
Partes diferentes de um bloco têm estatísticas diferentes. Cada grupo de 50 símbolos usa a tabela que fica mais barata para ele.

**Qual a complexidade do programa?**
Linear no tamanho do arquivo: SA-IS O(n), MTF O(n) (a lista tem no máximo 256 bytes, e a posição procurada costuma estar no começo), Huffman O(k log k) por tabela (k ≤ 258 símbolos) e CRC O(n).

**O CRC-32 garante que o arquivo está correto?**
Garante com probabilidade altíssima contra erros acidentais. Um erro concentrado em até 32 bits seguidos é sempre detectado, e outros escapam com chance de 1 em 4 bilhões. Contra alterações feitas de propósito seria preciso um resumo criptográfico.

**O trabalho pede ANSI C; por que há funções do Windows?**
O C ANSI não tem como abrir arquivos com nomes Unicode no Windows. Essa parte foi isolada em `sistema.c` sob `#ifdef _WIN32`; o resto do programa é C89 puro e compila com `-std=c89 -pedantic` sem avisos, em Windows e Linux.

**Onde há alocação dinâmica?**
Em `compressor.c` (buffers do bloco, uma vez por arquivo) e em `bwt.c` (vetor de tipos e baldes do SA-IS, liberados a cada nível da recursão). Tudo é liberado, inclusive nos erros.

---

## Referências

- M. Burrows e D. J. Wheeler. *A Block-sorting Lossless Data Compression Algorithm*. SRC Research Report 124, 1994.
- G. Nong, S. Zhang e W. H. Chan. *Linear Suffix Array Construction by Almost Pure Induced-Sorting*. Data Compression Conference, 2009.
- B. Balkenhol, S. Kurtz e Y. M. Shtarkov. *Modifications of the Burrows and Wheeler Data Compression Algorithm*. Data Compression Conference, 1999.
- D. A. Huffman. *A Method for the Construction of Minimum-Redundancy Codes*. Proceedings of the IRE, 1952.
- J. Seward. *bzip2*. Inspirou o formato dos blocos: RUNA/RUNB, grupos de 50 símbolos, várias tabelas, seletores em MTF + unário e comprimentos em delta.
- W. W. Peterson e D. T. Brown. *Cyclic Codes for Error Detection*. Proceedings of the IRE, 1961 (CRC).
- N. Ziviani. *Projeto de Algoritmos com implementações em Pascal e C*. 3. ed. Cengage Learning, 2018.
