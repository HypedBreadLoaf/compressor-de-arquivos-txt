/*
 * compressor.c - Compressao, descompressao e verificacao de arquivos .bwz.
 *
 * O arquivo e processado em blocos de ate BLOCO_MAXIMO bytes:
 *   compressao:    BWT (vetor de sufixos) -> MTF-2/zeros -> Huffman
 *   descompressao: Huffman -> zeros/MTF-2 inversa -> BWT inversa
 * Os buffers sao alocados uma unica vez e reaproveitados por todos os blocos.
 *
 * Arquivo .bwz (inteiros em little-endian):
 *   cabecalho:  "BWZ2" | tamanho maximo de bloco (4)
 *               | tamanho do nome (2) | nome do arquivo original, sem a pasta
 *               | CRC-32 dos bytes anteriores do cabecalho (4)
 *   cada bloco: tamanho original n (4) | CRC-32 acumulado (4)
 *               | indice primario (4) | ...
 *     indice primario 0 (nao compensou comprimir): os n bytes originais
 *     senao: tamanho codificado (4) | bits gerados por bloco_codifica
 *   fim:        n = 0 (4)
 *
 * O CRC-32 acumulado e o CRC de todo o arquivo original do inicio ate o fim
 * do bloco: detecta blocos alterados, trocados de lugar ou perdidos, e a
 * marca de fim detecta um arquivo cortado entre dois blocos. O cabecalho
 * tem o seu proprio CRC-32, que protege o nome original.
 */
#include <stdio.h>
#include <stdlib.h>
#include "compressor.h"
#include "bwt.h"
#include "bloco.h"
#include "crc32.h"
#include "sistema.h"

#define ASSINATURA "BWZ2"
#define TAM_CABECALHO (10 + BWZ_TAM_NOME)  /* assinatura, bloco, tamanho e nome */

#define ERRO_ABRIR "nao foi possivel abrir o arquivo de entrada"
#define ERRO_CRIAR "nao foi possivel criar o arquivo de saida"
#define ERRO_MEMORIA "memoria insuficiente"
#define ERRO_LEITURA "falha ao ler o arquivo de entrada"
#define ERRO_ESCRITA "falha ao gravar o arquivo de saida"
#define ERRO_FORMATO "o arquivo nao esta no formato .bwz"
#define ERRO_CABECALHO "arquivo comprimido corrompido (cabecalho invalido)"
#define ERRO_CRC_CABECALHO "arquivo corrompido: o CRC-32 do cabecalho nao confere"
#define ERRO_EXTRA "arquivo comprimido corrompido (ha dados apos o fim)"

/* mensagens de erro que indicam o numero do bloco */
static char mensagem[128];

/* Inteiros de 2 e 4 bytes em little-endian (byte menos significativo primeiro) */
static void poe_u16(unsigned char *p, unsigned long valor)
{
    p[0] = (unsigned char) (valor & 0xFF);
    p[1] = (unsigned char) ((valor >> 8) & 0xFF);
}

static void poe_u32(unsigned char *p, unsigned long valor)
{
    poe_u16(p, valor & 0xFFFF);
    poe_u16(p + 2, (valor >> 16) & 0xFFFF);
}

static unsigned long tira_u16(const unsigned char *p)
{
    return p[0] | (unsigned long) p[1] << 8;
}

static unsigned long tira_u32(const unsigned char *p)
{
    return tira_u16(p) | tira_u16(p + 2) << 16;
}

static void escreve_u32(FILE *f, unsigned long valor)
{
    unsigned char b[4];

    poe_u32(b, valor);
    fwrite(b, 1, 4, f);
}

/* Retorna 0 se o arquivo terminar antes dos 4 bytes */
static int le_u32(FILE *f, unsigned long *valor)
{
    unsigned char b[4];

    if (fread(b, 1, 4, f) != 4)
        return 0;
    *valor = tira_u32(b);
    return 1;
}

/* Fecha a saida e, se algo falhou, apaga o arquivo incompleto */
static const char *encerra(FILE *saida, const char *nome_saida, const char *erro)
{
    if (ferror(saida) && erro == NULL)
        erro = ERRO_ESCRITA;
    if (fclose(saida) != 0 && erro == NULL)
        erro = ERRO_ESCRITA;
    if (erro != NULL)
        sistema_apaga(nome_saida);
    return erro;
}

static void zera_info(InfoBwz *info)
{
    info->original = 0;
    info->comprimido = 0;
    info->blocos = 0;
    info->crc = 0;
    info->nome[0] = '\0';
}

static void grava_cabecalho(FILE *saida, unsigned long capacidade, const char *nome, int tam_nome)
{
    unsigned char cabecalho[TAM_CABECALHO];
    int i;

    for (i = 0; i < 4; i++)
        cabecalho[i] = (unsigned char) ASSINATURA[i];
    poe_u32(cabecalho + 4, capacidade);
    poe_u16(cabecalho + 8, (unsigned long) tam_nome);
    for (i = 0; i < tam_nome; i++)
        cabecalho[10 + i] = (unsigned char) nome[i];
    fwrite(cabecalho, 1, (size_t) (10 + tam_nome), saida);
    escreve_u32(saida, crc32_atualiza(0, cabecalho, (unsigned long) (10 + tam_nome)));
}

/* Tamanho do arquivo aberto, em bytes, ou -1 se nao for possivel obte-lo */
static long tamanho_arquivo(FILE *f)
{
    long tamanho = -1;

    if (fseek(f, 0L, SEEK_END) == 0)
        tamanho = ftell(f);
    rewind(f);
    return tamanho;
}

const char *comprime(const char *nome_entrada, const char *nome_saida, InfoBwz *info)
{
    FILE *entrada, *saida;
    unsigned char *texto, *trabalho;
    int *sa;
    const char *nome;
    unsigned long codificado, crc = 0;
    long tamanho;
    int capacidade, n, primario, tam_nome;
    const char *erro = NULL;

    zera_info(info);
    entrada = sistema_abre(nome_entrada, "rb");
    if (entrada == NULL)
        return ERRO_ABRIR;
    saida = sistema_abre(nome_saida, "wb");
    if (saida == NULL) {
        fclose(entrada);
        return ERRO_CRIAR;
    }

    /* arquivos pequenos usam blocos (e buffers) do seu proprio tamanho */
    tamanho = tamanho_arquivo(entrada);
    capacidade = BLOCO_MAXIMO;
    if (tamanho >= 0 && tamanho < BLOCO_MAXIMO)
        capacidade = tamanho > 0 ? (int) tamanho : 1;

    texto = (unsigned char *) malloc((size_t) capacidade);
    trabalho = (unsigned char *) malloc((size_t) capacidade);
    sa = (int *) malloc((size_t) capacidade * sizeof(int));
    if (texto == NULL || trabalho == NULL || sa == NULL)
        erro = ERRO_MEMORIA;

    /* cabecalho, com o nome original (sem a pasta) para restaurar a extensao */
    nome = nome_entrada + sistema_inicio_nome(nome_entrada);
    for (tam_nome = 0; nome[tam_nome] != '\0' && tam_nome < BWZ_TAM_NOME - 1; tam_nome++)
        info->nome[tam_nome] = nome[tam_nome];
    info->nome[tam_nome] = '\0';
    grava_cabecalho(saida, (unsigned long) capacidade, info->nome, tam_nome);

    while (erro == NULL && (n = (int) fread(texto, 1, (size_t) capacidade, entrada)) > 0) {
        crc = crc32_atualiza(crc, texto, (unsigned long) n);
        primario = bwt_direta(texto, n, sa, trabalho);
        if (primario < 0) {
            erro = ERRO_MEMORIA;
            break;
        }
        /* os simbolos do MTF reaproveitam a memoria de 'sa' (n+1 shorts cabem
           em n ints) e os bits vao para 'trabalho', ja lido pelo MTF */
        codificado = bloco_codifica(trabalho, n, (unsigned short *) sa, trabalho);

        escreve_u32(saida, (unsigned long) n);
        escreve_u32(saida, crc);
        if (codificado > 0 && codificado + 4 < (unsigned long) n) {
            escreve_u32(saida, (unsigned long) primario);
            escreve_u32(saida, codificado);
            fwrite(trabalho, 1, (size_t) codificado, saida);
        } else {
            escreve_u32(saida, 0);
            fwrite(texto, 1, (size_t) n, saida);
        }
        info->original += (unsigned long) n;
        info->blocos++;
    }
    if (erro == NULL && ferror(entrada))
        erro = ERRO_LEITURA;
    escreve_u32(saida, 0);  /* marca de fim */
    info->crc = crc;
    info->comprimido = (unsigned long) ftell(saida);

    free(texto);
    free(trabalho);
    free(sa);
    fclose(entrada);
    return encerra(saida, nome_saida, erro);
}

/* Le o cabecalho e grava em 'capacidade' o tamanho maximo de bloco */
static const char *le_cabecalho_aberto(FILE *entrada, unsigned long *capacidade, InfoBwz *info)
{
    unsigned char cabecalho[TAM_CABECALHO];
    unsigned long tam_nome, crc, i;
    unsigned char c;

    if (fread(cabecalho, 1, 10, entrada) != 10 || cabecalho[0] != ASSINATURA[0]
        || cabecalho[1] != ASSINATURA[1] || cabecalho[2] != ASSINATURA[2]
        || cabecalho[3] != ASSINATURA[3])
        return ERRO_FORMATO;
    *capacidade = tira_u32(cabecalho + 4);
    tam_nome = tira_u16(cabecalho + 8);
    if (*capacidade < 1 || *capacidade > BLOCO_MAXIMO || tam_nome >= BWZ_TAM_NOME
        || fread(cabecalho + 10, 1, (size_t) tam_nome, entrada) != tam_nome
        || !le_u32(entrada, &crc))
        return ERRO_CABECALHO;
    if (crc != crc32_atualiza(0, cabecalho, 10 + tam_nome))
        return ERRO_CRC_CABECALHO;

    /* o nome nao pode levar a outra pasta nem ter caracteres de controle */
    for (i = 0; i < tam_nome; i++) {
        c = cabecalho[10 + i];
        info->nome[i] = (char) (c == '/' || c == '\\' || c == ':' || c < ' ' ? '_' : c);
    }
    info->nome[tam_nome] = '\0';
    return NULL;
}

const char *le_cabecalho(const char *nome_entrada, InfoBwz *info)
{
    FILE *entrada;
    unsigned long capacidade;
    const char *erro;

    zera_info(info);
    entrada = sistema_abre(nome_entrada, "rb");
    if (entrada == NULL)
        return ERRO_ABRIR;
    erro = le_cabecalho_aberto(entrada, &capacidade, info);
    fclose(entrada);
    return erro;
}

/* Mensagem para um bloco que nao pode ser lido */
static const char *bloco_invalido(FILE *entrada, unsigned long bloco)
{
    if (feof(entrada))
        sprintf(mensagem, "arquivo comprimido incompleto (termina no bloco %lu)", bloco);
    else
        sprintf(mensagem, "arquivo comprimido corrompido (bloco %lu)", bloco);
    return mensagem;
}

/* Descomprime 'nome_entrada'. Com nome_saida NULL, apenas confere os CRC. */
static const char *processa(const char *nome_entrada, const char *nome_saida, InfoBwz *info)
{
    FILE *entrada, *saida = NULL;
    unsigned char *bloco, *codificado;
    unsigned int *psi;
    unsigned long capacidade, n, crc_gravado, primario, tamanho, numero, crc = 0;
    long tamanho_bwz;
    const char *erro;

    zera_info(info);
    entrada = sistema_abre(nome_entrada, "rb");
    if (entrada == NULL)
        return ERRO_ABRIR;
    tamanho_bwz = tamanho_arquivo(entrada);
    info->comprimido = tamanho_bwz > 0 ? (unsigned long) tamanho_bwz : 0;
    erro = le_cabecalho_aberto(entrada, &capacidade, info);
    if (erro == NULL && nome_saida != NULL) {
        saida = sistema_abre(nome_saida, "wb");
        if (saida == NULL)
            erro = ERRO_CRIAR;
    }
    if (erro != NULL) {
        fclose(entrada);
        return erro;
    }

    bloco = (unsigned char *) malloc((size_t) capacidade);
    psi = (unsigned int *) malloc(((size_t) capacidade + 1) * sizeof(unsigned int));
    /* os bits de cada bloco sao lidos na memoria de 'psi', que so e usada
       pela BWT inversa depois que eles foram decodificados */
    codificado = (unsigned char *) psi;
    if (bloco == NULL || psi == NULL)
        erro = ERRO_MEMORIA;

    while (erro == NULL) {
        numero = info->blocos + 1;
        if (!le_u32(entrada, &n)) {
            erro = bloco_invalido(entrada, numero);
            break;
        }
        if (n == 0) {  /* marca de fim: nada pode vir depois dela */
            if (fgetc(entrada) != EOF)
                erro = ERRO_EXTRA;
            break;
        }
        if (n > capacidade || !le_u32(entrada, &crc_gravado) || !le_u32(entrada, &primario)
            || primario > n) {
            erro = bloco_invalido(entrada, numero);
        } else if (primario == 0) {
            if (fread(bloco, 1, (size_t) n, entrada) != n)
                erro = bloco_invalido(entrada, numero);
        } else if (!le_u32(entrada, &tamanho) || tamanho < 1 || tamanho > n
                   || fread(codificado, 1, (size_t) tamanho, entrada) != tamanho
                   || !bloco_decodifica(codificado, tamanho, bloco, (int) n)) {
            erro = bloco_invalido(entrada, numero);
        } else {
            bwt_inversa(bloco, (int) n, (int) primario, psi);
        }

        /* confere o CRC antes de gravar: dados errados nunca vao para a saida */
        if (erro == NULL) {
            crc = crc32_atualiza(crc, bloco, n);
            if (crc != crc_gravado) {
                sprintf(mensagem, "arquivo corrompido: o CRC-32 do bloco %lu nao confere", numero);
                erro = mensagem;
            }
        }
        if (erro == NULL && saida != NULL && fwrite(bloco, 1, (size_t) n, saida) != n)
            erro = ERRO_ESCRITA;
        if (erro == NULL) {
            info->original += n;
            info->blocos++;
        }
    }
    if (erro == NULL && ferror(entrada))
        erro = ERRO_LEITURA;
    info->crc = crc;

    free(bloco);
    free(psi);
    fclose(entrada);
    return saida != NULL ? encerra(saida, nome_saida, erro) : erro;
}

const char *descomprime(const char *nome_entrada, const char *nome_saida, InfoBwz *info)
{
    return processa(nome_entrada, nome_saida, info);
}

const char *verifica(const char *nome_entrada, InfoBwz *info)
{
    return processa(nome_entrada, NULL, info);
}
