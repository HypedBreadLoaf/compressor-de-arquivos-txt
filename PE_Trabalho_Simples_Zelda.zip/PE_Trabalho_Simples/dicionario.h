/*
 * dicionario.h - TAD Dicionario: guarda, para cada simbolo, a sua
 * frequencia e o seu codigo de Huffman.
 *
 * Cada tabela de Huffman de um bloco (bloco.c) e um Dicionario.
 *
 * Compressao:
 *   dic_inicia -> dic_conta (para cada simbolo) -> dic_gera_codigos
 *   -> dic_grava (cabecalho) -> dic_codifica (para cada simbolo)
 * Descompressao:
 *   dic_le (reconstroi o dicionario a partir do cabecalho)
 *   -> dic_decodifica (para cada simbolo)
 *
 * Os simbolos sao inteiros de 0 a n-1, entao o proprio simbolo e a posicao
 * dos seus dados nos vetores (enderecamento direto): buscar ou atualizar um
 * simbolo custa O(1), sem colisoes, como uma tabela hash perfeita.
 *
 * Os codigos sao calculados pelo TAD Arvore de Huffman (huffman.h). Como
 * sao canonicos, basta gravar no arquivo o comprimento de cada codigo.
 */
#ifndef DICIONARIO_H
#define DICIONARIO_H

#include "bits.h"
#include "huffman.h"

typedef struct {
    int n;                                  /* quantidade de simbolos */
    unsigned long freq[HUF_MAX_SIMBOLOS];   /* frequencia de cada simbolo */
    unsigned char comp[HUF_MAX_SIMBOLOS];   /* comprimento do codigo, em bits */
    unsigned int codigo[HUF_MAX_SIMBOLOS];  /* codigo canonico */
    DecodificadorHuffman dec;               /* usado apenas na descompressao */
} Dicionario;

/* Prepara um dicionario vazio para os simbolos 0..n-1 (2 <= n <= HUF_MAX_SIMBOLOS) */
void dic_inicia(Dicionario *d, int n);

/* Registra mais uma ocorrencia do simbolo */
void dic_conta(Dicionario *d, int simbolo);

/* Gera os codigos de Huffman a partir das frequencias registradas */
void dic_gera_codigos(Dicionario *d);

/* Bits que os codigos de simbolos[inicio..fim-1] ocupam neste dicionario */
unsigned long dic_custo(const Dicionario *d, const unsigned short *simbolos, int inicio, int fim);

/* Grava o codigo do simbolo */
void dic_codifica(const Dicionario *d, FluxoBits *fb, int simbolo);

/* Grava os comprimentos dos codigos: e tudo que dic_le precisa para
   reconstruir o dicionario */
void dic_grava(const Dicionario *d, FluxoBits *fb);

/* Reconstroi um dicionario de n simbolos a partir do que dic_grava gravou.
   Retorna 0 se os comprimentos nao formarem um codigo de Huffman valido. */
int dic_le(Dicionario *d, FluxoBits *fb, int n);

/* Le um codigo e retorna o seu simbolo, ou -1 se o codigo for invalido */
int dic_decodifica(const Dicionario *d, FluxoBits *fb);

#endif
