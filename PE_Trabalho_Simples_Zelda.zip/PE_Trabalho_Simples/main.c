/*
 * main.c - Menu principal do UFABC BWZip.
 *
 * Compressor de arquivos baseado na Transformada de Burrows-Wheeler,
 * Move-to-Front e codificacao de Huffman com multiplas tabelas, com
 * verificacao de integridade por CRC-32.
 *
 * Integrantes do grupo: (preencher com nome e RA de cada integrante)
 */
#include <stdio.h>
#include <time.h>
#include "compressor.h"
#include "sistema.h"

#define TAM_CAMINHO 1024
#define EXTENSAO ".bwz"

/* Mostra a pergunta e le uma linha do teclado, sem espacos nas pontas e
   sem as aspas em volta (que o Windows acrescenta no "Copiar como caminho"
   e ao arrastar um arquivo para o terminal). Retorna 0 no fim da entrada. */
static int le_linha(const char *pergunta, char *s)
{
    int n = 0, inicio = 0, i;

    printf("%s", pergunta);
    fflush(stdout);
    if (!sistema_le_linha(s, TAM_CAMINHO))
        return 0;
    while (s[n] != '\0')
        n++;
    while (n > 0 && (s[n - 1] == ' ' || s[n - 1] == '\t'))
        n--;
    while (inicio < n && (s[inicio] == ' ' || s[inicio] == '\t'))
        inicio++;
    if (n - inicio >= 2 && (s[inicio] == '"' || s[inicio] == '\'') && s[n - 1] == s[inicio]) {
        inicio++;
        n--;
    }
    for (i = inicio; i < n; i++)
        s[i - inicio] = s[i];
    s[n - inicio] = '\0';
    return 1;
}

static int existe(const char *nome)
{
    FILE *f = sistema_abre(nome, "rb");

    if (f == NULL)
        return 0;
    fclose(f);
    return 1;
}

/* Posicao do ponto da extensao do nome do arquivo, ou o fim do caminho se
   nao houver extensao (".bashrc" nao tem extensao) */
static int inicio_extensao(const char *caminho)
{
    int i, nome = sistema_inicio_nome(caminho), ponto = -1;

    for (i = nome; caminho[i] != '\0'; i++)
        if (caminho[i] == '.' && i > nome)
            ponto = i;
    return ponto > nome ? ponto : i;
}

/* Grava em 'saida' os 'fim' primeiros caracteres de 'raiz' seguidos de
   'extensao'. Para nunca sobrescrever um arquivo, se esse nome ja existir
   tenta raiz_1, raiz_2, ... Retorna quantas tentativas falharam. */
static int nome_livre(const char *raiz, int fim, const char *extensao, char *saida)
{
    int k = 0;

    sprintf(saida, "%.*s%s", fim, raiz, extensao);
    while (existe(saida))
        sprintf(saida, "%.*s_%d%s", fim, raiz, ++k, extensao);
    return k;
}

static void mostra(const char *rotulo, const char *nome, unsigned long tamanho)
{
    printf("%-20s %-30s Tamanho: %lu Bytes\n", rotulo, nome, tamanho);
}

static double segundos_desde(clock_t inicio)
{
    return (double) (clock() - inicio) / CLOCKS_PER_SEC;
}

static void comprimir(void)
{
    char entrada[TAM_CAMINHO], saida[TAM_CAMINHO + 16];
    InfoBwz info;
    const char *erro;
    clock_t inicio;
    double tempo;

    if (!le_linha("Arquivo a comprimir: ", entrada) || entrada[0] == '\0')
        return;
    nome_livre(entrada, inicio_extensao(entrada), EXTENSAO, saida);

    printf("Comprimindo...\n");
    inicio = clock();
    erro = comprime(entrada, saida, &info);
    tempo = segundos_desde(inicio);
    if (erro != NULL) {
        printf("Erro: %s.\n", erro);
        return;
    }
    mostra("Arquivo original:", entrada, info.original);
    mostra("Arquivo comprimido:", saida, info.comprimido);
    if (info.original > 0)
        printf("Razao de compressao: %.4f\n", (double) info.comprimido / (double) info.original);
    printf("CRC-32 do original:  %08lX\n", info.crc);
    printf("Tempo de compressao: %.3f s\n", tempo);
}

/* Monta em 'desejado' o nome do arquivo restaurado a partir do que o
   usuario digitou, usando o nome original guardado no .bwz:
     nada (Enter)            -> nome original, na pasta do arquivo .bwz
     uma pasta ("C:\docs\")  -> nome original, nessa pasta
     um nome sem extensao    -> esse nome com a extensao original */
static void nome_restaurado(const char *entrada, const char *digitado, const char *original,
                            char *desejado)
{
    int fim, ext;

    if (digitado[0] == '\0') {
        sprintf(desejado, "%.*s%s", sistema_inicio_nome(entrada), entrada, original);
        return;
    }
    fim = inicio_extensao(digitado);
    ext = inicio_extensao(original);
    if (digitado[sistema_inicio_nome(digitado)] == '\0') {
        sprintf(desejado, "%s%s", digitado, original);
    } else if (digitado[fim] == '\0' && original[ext] != '\0') {
        sprintf(desejado, "%s%s", digitado, original + ext);
        printf("Extensao original (%s) adicionada: %s\n", original + ext, desejado);
    } else {
        sprintf(desejado, "%s", digitado);
    }
}

static void descomprimir(void)
{
    char entrada[TAM_CAMINHO], digitado[TAM_CAMINHO], padrao[2 * TAM_CAMINHO];
    char pergunta[2 * TAM_CAMINHO + 64], desejado[2 * TAM_CAMINHO], saida[2 * TAM_CAMINHO + 16];
    InfoBwz info;
    const char *erro;
    clock_t inicio;
    double tempo;
    int fim;

    if (!le_linha("Arquivo comprimido (" EXTENSAO "): ", entrada) || entrada[0] == '\0')
        return;
    erro = le_cabecalho(entrada, &info);
    if (erro != NULL) {
        printf("Erro: %s.\n", erro);
        return;
    }

    printf("Nome original do arquivo: %s\n", info.nome);
    nome_restaurado(entrada, "", info.nome, padrao);
    sprintf(pergunta, "Nome do arquivo restaurado [Enter = %s]: ", padrao);
    if (!le_linha(pergunta, digitado))
        return;
    nome_restaurado(entrada, digitado, info.nome, desejado);
    fim = inicio_extensao(desejado);
    if (desejado[sistema_inicio_nome(desejado)] == '\0') {
        printf("Erro: informe o nome do arquivo restaurado.\n");
        return;
    }
    if (nome_livre(desejado, fim, desejado + fim, saida) > 0)
        printf("%s ja existe; o arquivo sera restaurado como %s\n", desejado, saida);

    printf("Descomprimindo...\n");
    inicio = clock();
    erro = descomprime(entrada, saida, &info);
    tempo = segundos_desde(inicio);
    if (erro != NULL) {
        printf("Erro: %s.\n", erro);
        return;
    }
    mostra("Arquivo comprimido:", entrada, info.comprimido);
    mostra("Arquivo restaurado:", saida, info.original);
    printf("CRC-32 conferido:    %08lX (identico ao original)\n", info.crc);
    printf("Tempo de descompressao: %.3f s\n", tempo);
}

static void verificar(void)
{
    char entrada[TAM_CAMINHO];
    InfoBwz info;
    const char *erro;
    clock_t inicio;
    double tempo;

    if (!le_linha("Arquivo comprimido (" EXTENSAO "): ", entrada) || entrada[0] == '\0')
        return;

    printf("Verificando...\n");
    inicio = clock();
    erro = verifica(entrada, &info);
    tempo = segundos_desde(inicio);
    if (erro != NULL) {
        printf("Erro: %s.\n", erro);
        if (info.blocos > 0)
            printf("Blocos integros antes do erro: %lu\n", info.blocos);
        return;
    }
    mostra("Arquivo comprimido:", entrada, info.comprimido);
    mostra("Arquivo original:", info.nome, info.original);
    printf("Blocos conferidos:   %lu\n", info.blocos);
    printf("CRC-32 do original:  %08lX\n", info.crc);
    printf("Resultado: arquivo integro (todos os CRC-32 conferem)\n");
    printf("Tempo de verificacao: %.3f s\n", tempo);
}

int main(void)
{
    char opcao[TAM_CAMINHO];

    sistema_inicia();
    for (;;) {
        printf("\n==============================\n");
        printf("  Programa - UFABC BWZip\n");
        printf("==============================\n");
        printf("1) Comprimir\n2) Descomprimir\n3) Verificar integridade (CRC-32)\n0) Sair\n");
        if (!le_linha("Opcao: ", opcao) || (opcao[0] == '0' && opcao[1] == '\0'))
            break;
        printf("\n");
        if (opcao[0] == '1' && opcao[1] == '\0')
            comprimir();
        else if (opcao[0] == '2' && opcao[1] == '\0')
            descomprimir();
        else if (opcao[0] == '3' && opcao[1] == '\0')
            verificar();
        else
            printf("Opcao invalida.\n");
    }
    return 0;
}
