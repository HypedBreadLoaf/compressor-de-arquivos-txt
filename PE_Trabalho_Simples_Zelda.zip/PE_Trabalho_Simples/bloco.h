/*
 * bloco.h - Codificacao de um bloco ja transformado pela BWT: Move-to-Front,
 * sequencias de zeros e Huffman com multiplas tabelas.
 */
#ifndef BLOCO_H
#define BLOCO_H

/* Tamanho maximo de um bloco (8 MiB). Blocos maiores comprimem melhor, mas
   usam mais memoria. A BWT inversa (bwt.c) exige menos de 2^24 bytes. */
#define BLOCO_MAXIMO 8388608

/* Codifica os n bytes da BWT em 'saida', que tem espaco para n bytes e pode
   ser o proprio buffer da BWT. 'simbolos' e uma area de trabalho com n+1
   posicoes. Retorna o numero de bytes gerados, ou 0 se nao couberem em n. */
unsigned long bloco_codifica(const unsigned char *bwt, int n, unsigned short *simbolos,
                             unsigned char *saida);

/* Decodifica 'tamanho' bytes de 'entrada', gerando os n bytes da BWT.
   Retorna 0 se os dados estiverem corrompidos. */
int bloco_decodifica(unsigned char *entrada, unsigned long tamanho, unsigned char *bwt, int n);

#endif
