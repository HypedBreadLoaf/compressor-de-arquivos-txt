/*
 * bwt.c - Transformada de Burrows-Wheeler direta e inversa.
 *
 * A BWT direta e obtida do vetor de sufixos, construido em tempo O(n) pelo
 * algoritmo SA-IS (Nong, Zhang e Chan, 2009). Cada sufixo e do tipo S
 * (menor que o sufixo seguinte) ou L (maior). Basta ordenar os sufixos LMS
 * (tipo S precedidos por um tipo L); a ordem de todos os outros e deduzida
 * ("induzida") em duas varreduras lineares. Para ordenar os LMS, o algoritmo
 * gera um texto reduzido e se chama recursivamente.
 */
#include <stdlib.h>
#include <limits.h>
#include "bwt.h"

#if INT_MAX < 2147483647
#error "Este programa requer int de pelo menos 32 bits"
#endif

/* Simbolo i do texto: bytes no nivel 0, inteiros nos niveis recursivos */
#define SIMBOLO(i) (largura == 1 ? (int) ((const unsigned char *) s)[i] : ((const int *) s)[i])

/* Tipos dos sufixos em um vetor de bits: 1 = tipo S, 0 = tipo L */
#define TIPO_S(i) ((tipos[(i) >> 3] >> ((i) & 7)) & 1)
#define MARCA_S(i) (tipos[(i) >> 3] |= (unsigned char) (1 << ((i) & 7)))
#define EH_LMS(i) ((i) > 0 && TIPO_S(i) && !TIPO_S((i) - 1))

/* Calcula o inicio (fim = 0) ou o fim (fim = 1) do balde de cada simbolo */
static void calcula_baldes(const void *s, int largura, int n, int k, int *baldes, int fim)
{
    int i, soma = 0;

    for (i = 0; i < k; i++)
        baldes[i] = 0;
    for (i = 0; i < n; i++)
        baldes[SIMBOLO(i)]++;
    for (i = 0; i < k; i++) {
        soma += baldes[i];
        baldes[i] = fim ? soma : soma - baldes[i];
    }
}

/* Induz a ordem dos sufixos a partir dos que ja estao em sa: da esquerda
   para a direita, cada sufixo do tipo L vai para o inicio do seu balde;
   depois, da direita para a esquerda, cada tipo S vai para o fim do seu. */
static void induz(const unsigned char *tipos, int *sa, const void *s, int largura,
                  int n, int k, int *baldes)
{
    int i, j;

    calcula_baldes(s, largura, n, k, baldes, 0);
    /* o sentinela e o menor sufixo; o sufixo n-1 (tipo L) e induzido por ele */
    sa[baldes[SIMBOLO(n - 1)]++] = n - 1;
    for (i = 0; i < n; i++) {
        j = sa[i] - 1;
        if (j >= 0 && !TIPO_S(j))
            sa[baldes[SIMBOLO(j)]++] = j;
    }

    calcula_baldes(s, largura, n, k, baldes, 1);
    for (i = n - 1; i >= 0; i--) {
        j = sa[i] - 1;
        if (j >= 0 && TIPO_S(j))
            sa[--baldes[SIMBOLO(j)]] = j;
    }
}

/* Vetor de sufixos de s: n simbolos no intervalo [0, k), de 'largura'
   bytes cada (1 ou sizeof(int)). Retorna -1 se faltar memoria. */
static int sais(const void *s, int *sa, int n, int k, int largura)
{
    unsigned char *tipos;
    int *baldes, *s1;
    int i, j, n1, nomes, anterior, pos, d, diferente, erro = 0;

    tipos = (unsigned char *) calloc((size_t) n / 8 + 1, 1);
    baldes = (int *) malloc((size_t) k * sizeof(int));
    if (tipos == NULL || baldes == NULL) {
        free(tipos);
        free(baldes);
        return -1;
    }

    /* 1. Classifica os sufixos (o ultimo e do tipo L, pois o sentinela e menor) */
    for (i = n - 2; i >= 0; i--)
        if (SIMBOLO(i) < SIMBOLO(i + 1) || (SIMBOLO(i) == SIMBOLO(i + 1) && TIPO_S(i + 1)))
            MARCA_S(i);

    /* 2. Ordena as subcadeias LMS: coloca as posicoes LMS no fim dos baldes
          e induz a ordem */
    calcula_baldes(s, largura, n, k, baldes, 1);
    for (i = 0; i < n; i++)
        sa[i] = -1;
    for (i = 1; i < n; i++)
        if (EH_LMS(i))
            sa[--baldes[SIMBOLO(i)]] = i;
    induz(tipos, sa, s, largura, n, k, baldes);

    /* 3. Move as posicoes LMS, agora ordenadas, para o inicio de sa */
    n1 = 0;
    for (i = 0; i < n; i++)
        if (EH_LMS(sa[i]))
            sa[n1++] = sa[i];

    /* 4. Da nomes as subcadeias LMS: subcadeias iguais recebem o mesmo nome.
          Como duas posicoes LMS distam pelo menos 2, pos/2 nao colide. */
    for (i = n1; i < n; i++)
        sa[i] = -1;
    nomes = 0;
    anterior = -1;
    for (i = 0; i < n1; i++) {
        pos = sa[i];
        diferente = 0;
        for (d = 0;; d++) {
            if (anterior < 0 || pos + d == n || anterior + d == n
                || SIMBOLO(pos + d) != SIMBOLO(anterior + d)
                || TIPO_S(pos + d) != TIPO_S(anterior + d)) {
                diferente = 1;
                break;
            }
            if (d > 0 && (EH_LMS(pos + d) || EH_LMS(anterior + d)))
                break;
        }
        if (diferente) {
            nomes++;
            anterior = pos;
        }
        sa[n1 + pos / 2] = nomes - 1;
    }

    /* texto reduzido s1: os nomes na ordem em que aparecem no texto */
    for (i = n - 1, j = n - 1; i >= n1; i--)
        if (sa[i] >= 0)
            sa[j--] = sa[i];
    s1 = sa + n - n1;

    /* 5. Ordena os sufixos de s1 (recursao apenas se ha nomes repetidos).
          Os baldes sao liberados durante a recursao para economizar memoria. */
    if (nomes < n1) {
        free(baldes);
        baldes = NULL;
        if (sais(s1, sa, n1, nomes, (int) sizeof(int)) == 0)
            baldes = (int *) malloc((size_t) k * sizeof(int));
        erro = baldes == NULL ? -1 : 0;
    } else {
        for (i = 0; i < n1; i++)
            sa[s1[i]] = i;
    }

    /* 6. Traduz para posicoes do texto, coloca os sufixos LMS ordenados no
          fim dos baldes e induz a ordem final de todos os sufixos */
    if (erro == 0) {
        for (i = 1, j = 0; i < n; i++)
            if (EH_LMS(i))
                s1[j++] = i;
        for (i = 0; i < n1; i++)
            sa[i] = s1[sa[i]];
        for (i = n1; i < n; i++)
            sa[i] = -1;
        calcula_baldes(s, largura, n, k, baldes, 1);
        for (i = n1 - 1; i >= 0; i--) {
            j = sa[i];
            sa[i] = -1;
            sa[--baldes[SIMBOLO(j)]] = j;
        }
        induz(tipos, sa, s, largura, n, k, baldes);
    }

    free(baldes);
    free(tipos);
    return erro;
}

int bwt_direta(const unsigned char *texto, int n, int *sa, unsigned char *bwt)
{
    int i, k = 1, primario = 0;

    if (n == 1)
        sa[0] = 0;
    else if (sais(texto, sa, n, 256, 1) != 0)
        return -1;

    /* linha 0: sufixo vazio (sentinela), precedido pelo ultimo caractere */
    bwt[0] = texto[n - 1];
    for (i = 0; i < n; i++) {
        if (sa[i] == 0)
            primario = i + 1;  /* linha em que estaria o sentinela */
        else
            bwt[k++] = texto[sa[i] - 1];
    }
    return primario;
}

/*
 * Para cada linha r da primeira coluna (F), psi[r] guarda a linha da ultima
 * coluna (L) onde esta a mesma ocorrencia do caractere F[r], que e a linha
 * do sufixo seguinte. Partindo da linha do sufixo 0 (o indice primario), o
 * texto e reconstruido do inicio para o fim.
 *
 * Cada entrada guarda (linha << 8) | caractere em 32 bits, pois os blocos
 * tem menos de 2^24 bytes; assim cada passo faz um unico acesso a memoria.
 */
void bwt_inversa(unsigned char *bloco, int n, int primario, unsigned int *psi)
{
    int inicio[256];
    int c, j, k, linha;

    for (c = 0; c < 256; c++)
        inicio[c] = 0;
    for (j = 0; j < n; j++)
        inicio[bloco[j]]++;

    /* primeira linha de cada caractere na coluna F (a linha 0 e do sentinela) */
    k = 1;
    for (c = 0; c < 256; c++) {
        j = inicio[c];
        inicio[c] = k;
        k += j;
    }

    psi[0] = (unsigned int) primario << 8;
    for (j = 0; j < n; j++) {
        c = bloco[j];
        linha = j < primario ? j : j + 1;  /* pula a linha do sentinela */
        psi[inicio[c]++] = ((unsigned int) linha << 8) | (unsigned int) c;
    }

    linha = primario;
    for (k = 0; k < n; k++) {
        bloco[k] = (unsigned char) (psi[linha] & 0xFF);
        linha = (int) (psi[linha] >> 8);
    }
}
