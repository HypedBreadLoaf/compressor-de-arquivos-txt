/*
 * dicionario.c - TAD Dicionario: simbolos, frequencias e codigos de Huffman.
 */
#include "dicionario.h"

void dic_inicia(Dicionario *d, int n)
{
    int s;

    d->n = n;
    for (s = 0; s < n; s++) {
        d->freq[s] = 0;
        d->comp[s] = 0;
        d->codigo[s] = 0;
    }
}

void dic_conta(Dicionario *d, int simbolo)
{
    d->freq[simbolo]++;
}

void dic_gera_codigos(Dicionario *d)
{
    huf_comprimentos(d->freq, d->n, d->comp);  /* arvore de Huffman */
    huf_codigos(d->comp, d->n, d->codigo);     /* codigos canonicos */
}

unsigned long dic_custo(const Dicionario *d, const unsigned short *simbolos, int inicio, int fim)
{
    unsigned long bits = 0;

    for (; inicio < fim; inicio++)
        bits += d->comp[simbolos[inicio]];
    return bits;
}

void dic_codifica(const Dicionario *d, FluxoBits *fb, int simbolo)
{
    bits_escreve(fb, d->codigo[simbolo], d->comp[simbolo]);
}

/* Comprimentos vizinhos costumam ser parecidos, entao grava-se o primeiro
   em 5 bits e, para cada simbolo, a diferenca para o anterior: "10" soma 1,
   "11" subtrai 1 e "0" passa ao proximo simbolo. */
void dic_grava(const Dicionario *d, FluxoBits *fb)
{
    int s, atual = d->comp[0];

    bits_escreve(fb, (unsigned long) atual, 5);
    for (s = 0; s < d->n; s++) {
        for (; atual < d->comp[s]; atual++)
            bits_escreve(fb, 2, 2);
        for (; atual > d->comp[s]; atual--)
            bits_escreve(fb, 3, 2);
        bits_escreve(fb, 0, 1);
    }
}

int dic_le(Dicionario *d, FluxoBits *fb, int n)
{
    unsigned long kraft = 0;
    int s, atual = (int) bits_le(fb, 5);

    d->n = n;
    for (s = 0; s < n; s++) {
        while (bits_le(fb, 1))
            atual += bits_le(fb, 1) ? -1 : 1;
        if (atual < 1 || atual > HUF_MAX_COMPRIMENTO)
            return 0;
        d->comp[s] = (unsigned char) atual;
        kraft += 1UL << (HUF_MAX_COMPRIMENTO - atual);
    }
    /* desigualdade de Kraft: a arvore de Huffman e completa, entao a soma
       de 2^-comprimento de todos os codigos tem de ser exatamente 1 */
    if (kraft != 1UL << HUF_MAX_COMPRIMENTO)
        return 0;
    huf_prepara(&d->dec, d->comp, n);
    return 1;
}

int dic_decodifica(const Dicionario *d, FluxoBits *fb)
{
    return huf_decodifica(&d->dec, fb);
}
