/*
 * bits.h - Leitura e escrita de sequencias de bits em um buffer na memoria.
 *
 * Os bits sao gravados do mais significativo para o menos significativo
 * dentro de cada byte.
 */
#ifndef BITS_H
#define BITS_H

typedef struct {
    unsigned char *dados;
    unsigned long tamanho;  /* tamanho do buffer, em bytes */
    unsigned long pos;      /* proximo bit a ser lido ou gravado */
} FluxoBits;

void bits_inicia(FluxoBits *fb, unsigned char *dados, unsigned long tamanho);

/* Grava os n bits menos significativos de 'valor'. Alem do fim do buffer
   nada e gravado, mas a posicao continua avancando (ver bits_bytes). */
void bits_escreve(FluxoBits *fb, unsigned long valor, int n);

/* Le n bits. Alem do fim do buffer, le zeros. */
unsigned long bits_le(FluxoBits *fb, int n);

/* Bytes ocupados ate a posicao atual: se for maior que fb->tamanho, a
   escrita ou a leitura passou do fim do buffer */
unsigned long bits_bytes(const FluxoBits *fb);

#endif
