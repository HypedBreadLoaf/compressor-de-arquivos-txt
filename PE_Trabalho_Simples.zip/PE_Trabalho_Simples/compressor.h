/*
 * compressor.h - Compressao e descompressao de arquivos.
 *
 * As duas funcoes gravam o tamanho do arquivo original e o do comprimido
 * em 'original' e 'comprimido', em bytes, e retornam NULL em caso de
 * sucesso ou uma mensagem de erro. Se houver erro, o arquivo de saida
 * incompleto e apagado.
 */
#ifndef COMPRESSOR_H
#define COMPRESSOR_H

const char *comprime(const char *nome_entrada, const char *nome_saida,
                     unsigned long *original, unsigned long *comprimido);

const char *descomprime(const char *nome_entrada, const char *nome_saida,
                        unsigned long *original, unsigned long *comprimido);

#endif
