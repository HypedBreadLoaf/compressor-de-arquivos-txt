/*
 * compressor.c - Compressao e descompressao de arquivos.
 *
 * O arquivo e processado em blocos de ate BLOCO_MAXIMO bytes:
 *   compressao:    BWT (vetor de sufixos) -> MTF-2/zeros -> Huffman
 *   descompressao: Huffman -> zeros/MTF-2 inversa -> BWT inversa
 * Os buffers sao alocados uma unica vez e reaproveitados por todos os blocos.
 *
 * Arquivo .bwz (inteiros de 4 bytes em little-endian):
 *   cabecalho: "BWZ" | tamanho maximo de bloco
 *   cada bloco: tamanho original n | indice primario | ...
 *     indice primario 0 (nao compensou comprimir): os n bytes originais
 *     senao: tamanho codificado | bits gerados por bloco_codifica
 */
#include <stdio.h>
#include <stdlib.h>
#include "compressor.h"
#include "bwt.h"
#include "bloco.h"

#define ERRO_ABRIR "nao foi possivel abrir o arquivo de entrada"
#define ERRO_CRIAR "nao foi possivel criar o arquivo de saida"
#define ERRO_MEMORIA "memoria insuficiente"
#define ERRO_LEITURA "falha ao ler o arquivo de entrada"
#define ERRO_ESCRITA "falha ao gravar o arquivo de saida"
#define ERRO_FORMATO "o arquivo nao esta no formato .bwz"
#define ERRO_CORROMPIDO "arquivo comprimido corrompido"

static void escreve_u32(FILE *f, unsigned long valor)
{
    fputc((int) (valor & 0xFF), f);
    fputc((int) ((valor >> 8) & 0xFF), f);
    fputc((int) ((valor >> 16) & 0xFF), f);
    fputc((int) ((valor >> 24) & 0xFF), f);
}

/* Retorna 0 se o arquivo terminar antes dos 4 bytes */
static int le_u32(FILE *f, unsigned long *valor)
{
    unsigned char b[4];

    if (fread(b, 1, 4, f) != 4)
        return 0;
    *valor = b[0] | (unsigned long) b[1] << 8 | (unsigned long) b[2] << 16
             | (unsigned long) b[3] << 24;
    return 1;
}

/* Fecha a saida e, se algo falhou, apaga o arquivo incompleto */
static const char *encerra(FILE *saida, const char *nome_saida, const char *erro)
{
    if (ferror(saida) && erro == NULL)
        erro = ERRO_ESCRITA;
    if (fclose(saida) != 0 && erro == NULL)
        erro = ERRO_ESCRITA;
    if (erro != NULL)
        remove(nome_saida);
    return erro;
}

const char *comprime(const char *nome_entrada, const char *nome_saida,
                     unsigned long *original, unsigned long *comprimido)
{
    FILE *entrada, *saida;
    unsigned char *texto, *trabalho;
    int *sa;
    long tamanho;
    int capacidade, n, primario;
    unsigned long codificado;
    const char *erro = NULL;

    *original = 0;
    *comprimido = 0;
    entrada = fopen(nome_entrada, "rb");
    if (entrada == NULL)
        return ERRO_ABRIR;
    saida = fopen(nome_saida, "wb");
    if (saida == NULL) {
        fclose(entrada);
        return ERRO_CRIAR;
    }

    /* arquivos pequenos usam blocos (e buffers) do seu proprio tamanho */
    fseek(entrada, 0L, SEEK_END);
    tamanho = ftell(entrada);
    rewind(entrada);
    capacidade = BLOCO_MAXIMO;
    if (tamanho >= 0 && tamanho < BLOCO_MAXIMO)
        capacidade = tamanho > 0 ? (int) tamanho : 1;

    texto = (unsigned char *) malloc((size_t) capacidade);
    trabalho = (unsigned char *) malloc((size_t) capacidade);
    sa = (int *) malloc((size_t) capacidade * sizeof(int));
    if (texto == NULL || trabalho == NULL || sa == NULL)
        erro = ERRO_MEMORIA;

    fwrite("BWZ", 1, 3, saida);
    escreve_u32(saida, (unsigned long) capacidade);
    while (erro == NULL && (n = (int) fread(texto, 1, (size_t) capacidade, entrada)) > 0) {
        primario = bwt_direta(texto, n, sa, trabalho);
        if (primario < 0) {
            erro = ERRO_MEMORIA;
            break;
        }
        /* os simbolos do MTF reaproveitam a memoria de 'sa' (n+1 shorts cabem
           em n ints) e os bits vao para 'trabalho', ja lido pelo MTF */
        codificado = bloco_codifica(trabalho, n, (unsigned short *) sa, trabalho);

        escreve_u32(saida, (unsigned long) n);
        if (codificado > 0 && codificado + 4 < (unsigned long) n) {
            escreve_u32(saida, (unsigned long) primario);
            escreve_u32(saida, codificado);
            fwrite(trabalho, 1, (size_t) codificado, saida);
        } else {
            escreve_u32(saida, 0);
            fwrite(texto, 1, (size_t) n, saida);
        }
        *original += (unsigned long) n;
    }
    if (erro == NULL && ferror(entrada))
        erro = ERRO_LEITURA;
    *comprimido = (unsigned long) ftell(saida);

    free(texto);
    free(trabalho);
    free(sa);
    fclose(entrada);
    return encerra(saida, nome_saida, erro);
}

const char *descomprime(const char *nome_entrada, const char *nome_saida,
                        unsigned long *original, unsigned long *comprimido)
{
    FILE *entrada, *saida;
    char assinatura[3];
    unsigned char *bloco, *codificado;
    unsigned int *psi;
    unsigned long capacidade, n, primario, tamanho;
    const char *erro = NULL;

    *original = 0;
    *comprimido = 0;
    entrada = fopen(nome_entrada, "rb");
    if (entrada == NULL)
        return ERRO_ABRIR;
    if (fread(assinatura, 1, 3, entrada) != 3 || assinatura[0] != 'B' || assinatura[1] != 'W'
        || assinatura[2] != 'Z' || !le_u32(entrada, &capacidade)
        || capacidade < 1 || capacidade > BLOCO_MAXIMO) {
        fclose(entrada);
        return ERRO_FORMATO;
    }
    saida = fopen(nome_saida, "wb");
    if (saida == NULL) {
        fclose(entrada);
        return ERRO_CRIAR;
    }

    bloco = (unsigned char *) malloc((size_t) capacidade);
    psi = (unsigned int *) malloc(((size_t) capacidade + 1) * sizeof(unsigned int));
    /* os bits de cada bloco sao lidos na memoria de 'psi', que so e usada
       pela BWT inversa depois que eles foram decodificados */
    codificado = (unsigned char *) psi;
    if (bloco == NULL || psi == NULL)
        erro = ERRO_MEMORIA;

    while (erro == NULL && le_u32(entrada, &n)) {
        if (n < 1 || n > capacidade || !le_u32(entrada, &primario) || primario > n) {
            erro = ERRO_CORROMPIDO;
        } else if (primario == 0) {
            if (fread(bloco, 1, (size_t) n, entrada) != n)
                erro = ERRO_CORROMPIDO;
        } else if (!le_u32(entrada, &tamanho) || tamanho < 1 || tamanho > n
                   || fread(codificado, 1, (size_t) tamanho, entrada) != tamanho
                   || !bloco_decodifica(codificado, tamanho, bloco, (int) n)) {
            erro = ERRO_CORROMPIDO;
        } else {
            bwt_inversa(bloco, (int) n, (int) primario, psi);
        }
        if (erro == NULL && fwrite(bloco, 1, (size_t) n, saida) != n)
            erro = ERRO_ESCRITA;
        *original += n;
    }
    if (erro == NULL && ferror(entrada))
        erro = ERRO_LEITURA;
    *comprimido = (unsigned long) ftell(entrada);

    free(bloco);
    free(psi);
    fclose(entrada);
    return encerra(saida, nome_saida, erro);
}
