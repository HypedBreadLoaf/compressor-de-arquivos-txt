/*
 * main.c - Menu principal do UFABC BWZip.
 *
 * Compressor de arquivos baseado na Transformada de Burrows-Wheeler,
 * Move-to-Front e codificacao de Huffman com multiplas tabelas.
 *
 * Integrantes do grupo: (preencher com nome e RA de cada integrante)
 */
#include <stdio.h>
#include <time.h>
#include "compressor.h"

#define TAM_CAMINHO 1024
#define EXTENSAO ".bwz"

/* Mostra a pergunta e le uma linha do teclado, sem o '\n', sem espacos no
   fim e sem as aspas em volta (que o terminal acrescenta ao arrastar um
   arquivo). Retorna 0 no fim da entrada. */
static int le_linha(const char *pergunta, char *s)
{
    int n = 0, c;

    printf("%s", pergunta);
    fflush(stdout);
    if (fgets(s, TAM_CAMINHO, stdin) == NULL)
        return 0;
    while (s[n] != '\0')
        n++;
    if (n > 0 && s[n - 1] != '\n')  /* linha longa demais: descarta o resto */
        while ((c = getchar()) != '\n' && c != EOF)
            ;
    while (n > 0 && (s[n - 1] == '\n' || s[n - 1] == '\r' || s[n - 1] == ' '))
        s[--n] = '\0';
    if (n >= 2 && (s[0] == '"' || s[0] == '\'') && s[n - 1] == s[0]) {
        for (c = 1; c < n - 1; c++)
            s[c - 1] = s[c];
        s[n - 2] = '\0';
    }
    return 1;
}

static int existe(const char *nome)
{
    FILE *f = fopen(nome, "rb");

    if (f == NULL)
        return 0;
    fclose(f);
    return 1;
}

/* Posicao do ponto da extensao do nome do arquivo, ou o fim do caminho se
   nao houver extensao (".bashrc" nao tem extensao) */
static int inicio_extensao(const char *caminho)
{
    int i, nome = 0, ponto = -1;

    for (i = 0; caminho[i] != '\0'; i++) {
        if (caminho[i] == '/' || caminho[i] == '\\')
            nome = i + 1;
        else if (caminho[i] == '.' && i > nome)
            ponto = i;
    }
    return ponto > nome ? ponto : i;
}

/* Grava em 'saida' os 'fim' primeiros caracteres de 'raiz' seguidos de
   'extensao'. Para nunca sobrescrever um arquivo, se esse nome ja existir
   tenta raiz_1, raiz_2, ... Retorna quantas tentativas falharam. */
static int nome_livre(const char *raiz, int fim, const char *extensao, char *saida)
{
    int k = 0;

    sprintf(saida, "%.*s%s", fim, raiz, extensao);
    while (existe(saida))
        sprintf(saida, "%.*s_%d%s", fim, raiz, ++k, extensao);
    return k;
}

static void mostra(const char *rotulo, const char *nome, unsigned long tamanho)
{
    printf("%-20s %-30s Tamanho: %lu Bytes\n", rotulo, nome, tamanho);
}

static double segundos_desde(clock_t inicio)
{
    return (double) (clock() - inicio) / CLOCKS_PER_SEC;
}

static void comprimir(void)
{
    char entrada[TAM_CAMINHO], saida[TAM_CAMINHO + 16];
    unsigned long original, comprimido;
    const char *erro;
    clock_t inicio;
    double tempo;

    if (!le_linha("Arquivo a comprimir: ", entrada) || entrada[0] == '\0')
        return;
    nome_livre(entrada, inicio_extensao(entrada), EXTENSAO, saida);

    printf("Comprimindo...\n");
    inicio = clock();
    erro = comprime(entrada, saida, &original, &comprimido);
    tempo = segundos_desde(inicio);
    if (erro != NULL) {
        printf("Erro: %s.\n", erro);
        return;
    }
    mostra("Arquivo original:", entrada, original);
    mostra("Arquivo comprimido:", saida, comprimido);
    if (original > 0)
        printf("Razao de compressao: %.4f\n", (double) comprimido / (double) original);
    printf("Tempo de compressao: %.3f s\n", tempo);
}

static void descomprimir(void)
{
    char entrada[TAM_CAMINHO], desejado[TAM_CAMINHO], saida[TAM_CAMINHO + 16];
    unsigned long original, comprimido;
    const char *erro;
    clock_t inicio;
    double tempo;
    int fim;

    if (!le_linha("Arquivo comprimido (" EXTENSAO "): ", entrada) || entrada[0] == '\0'
        || !le_linha("Nome do arquivo restaurado: ", desejado) || desejado[0] == '\0')
        return;
    fim = inicio_extensao(desejado);
    if (nome_livre(desejado, fim, desejado + fim, saida) > 0)
        printf("%s ja existe; o arquivo sera restaurado como %s\n", desejado, saida);

    printf("Descomprimindo...\n");
    inicio = clock();
    erro = descomprime(entrada, saida, &original, &comprimido);
    tempo = segundos_desde(inicio);
    if (erro != NULL) {
        printf("Erro: %s.\n", erro);
        return;
    }
    mostra("Arquivo comprimido:", entrada, comprimido);
    mostra("Arquivo restaurado:", saida, original);
    printf("Tempo de descompressao: %.3f s\n", tempo);
}

int main(void)
{
    char opcao[TAM_CAMINHO];

    for (;;) {
        printf("\n==============================\n");
        printf("  Programa - UFABC BWZip\n");
        printf("==============================\n");
        printf("1) Comprimir\n2) Descomprimir\n3) Sair\n");
        if (!le_linha("Opcao: ", opcao) || (opcao[0] == '3' && opcao[1] == '\0'))
            break;
        printf("\n");
        if (opcao[0] == '1' && opcao[1] == '\0')
            comprimir();
        else if (opcao[0] == '2' && opcao[1] == '\0')
            descomprimir();
        else
            printf("Opcao invalida.\n");
    }
    return 0;
}
