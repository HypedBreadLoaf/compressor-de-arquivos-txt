/* bwt.c - Transformada de Burrows-Wheeler (ordenação de rotações por duplicação de prefixos)
           e Move-to-Front com codificação de sequências de zeros (RUNA/RUNB) */

/* Ordena as n rotações de s; ao final sa[i] = início da i-ésima menor rotação. O(n log n) */
static void bwt_ordena(const unsigned char *s, long n, int *sa, int *rk, int *tmp, int *cnt) {
    long i, k, c, cls, a, pa = 0;
    int *t;
    for (i = 0; i < 256; i++) cnt[i] = 0;
    for (i = 0; i < n; i++) cnt[s[i]]++;
    for (i = 1; i < 256; i++) cnt[i] += cnt[i - 1];
    for (i = n - 1; i >= 0; i--) sa[--cnt[s[i]]] = (int)i;
    for (cls = 0, i = 0; i < n; i++) rk[sa[i]] = (int)(cls += i && s[sa[i]] != s[sa[i - 1]]);
    for (k = 1, cls++; k < n && cls < n; k <<= 1, cls = c) {
        for (i = 0; i < n; i++) tmp[i] = (int)(sa[i] >= k ? sa[i] - k : sa[i] - k + n);
        for (i = 0; i < cls; i++) cnt[i] = 0;                    /* counting sort pela 1a metade */
        for (i = 0; i < n; i++) cnt[rk[tmp[i]]]++;
        for (i = 1; i < cls; i++) cnt[i] += cnt[i - 1];
        for (i = n - 1; i >= 0; i--) sa[--cnt[rk[tmp[i]]]] = tmp[i];
        for (c = 0, i = 0; i < n; i++, pa = a) {                 /* novas classes (prefixos de 2k) */
            a = sa[i] + k < n ? sa[i] + k : sa[i] + k - n;
            if (i && (rk[sa[i]] != rk[sa[i - 1]] || rk[a] != rk[pa])) c++;
            tmp[sa[i]] = (int)c;
        }
        t = rk; rk = tmp; tmp = t;
        if (++c == cls) break;   /* classes estáveis: nenhuma rotação diferente resta empatada */
    }
}

/* Última coluna da BWT -> Move-to-Front -> sequências de zeros em base bijetiva 2 (0=RUNA, 1=RUNB).
   var=1 usa MTF-2: o símbolo vai para a posição 1; da posição 1 vai para a 0 só se o índice anterior não foi 0 */
static long mtf_cod(const unsigned char *s, long n, const int *sa, const unsigned char *usado, int var,
                    unsigned short *sym, long *prim) {
    unsigned char lista[256], c;
    long i, m = 0, run = 0;
    int j, d, nu = 0, ult = 1;
    for (j = 0; j < 256; j++) if (usado[j]) lista[nu++] = (unsigned char)j;
    for (i = 0; i < n; i++) {
        if (sa[i] == 0) *prim = i;
        c = s[sa[i] ? sa[i] - 1 : n - 1];
        for (j = 0; lista[j] != c; j++);
        if (!j) { run++; ult = 0; continue; }
        for (; run > 0; run = (run - 1) >> 1) sym[m++] = (unsigned short)!(run & 1);
        for (sym[m++] = (unsigned short)(j + 1), d = var && (j > 1 || !ult); j > d; j--) lista[j] = lista[j - 1];
        lista[d] = c;
        ult = 1;
    }
    for (; run > 0; run = (run - 1) >> 1) sym[m++] = (unsigned short)!(run & 1);
    return m;
}

/* Reconstrói o bloco a partir da última coluna L e da linha p da rotação original (mapeamento LF) */
static void bwt_inversa(const unsigned char *L, long n, long p, unsigned char *out, int *T) {
    long C[256], i, s, t;
    for (i = 0; i < 256; i++) C[i] = 0;
    for (i = 0; i < n; i++) C[L[i]]++;
    for (s = 0, i = 0; i < 256; i++) { t = C[i]; C[i] = s; s += t; }
    for (i = 0; i < n; i++) T[i] = (int)C[L[i]]++;
    for (i = n - 1; i >= 0; i--) { out[i] = L[p]; p = T[p]; }
}
