/* bits.c - TAD Fluxo de Bits: escrita e leitura bit a bit sobre um buffer em memória */
typedef struct { unsigned char *buf; long cap, pos; unsigned int acc; int n; } Bits;

static void bits_ini(Bits *b, unsigned char *buf, long cap) {
    b->buf = buf; b->cap = cap; b->pos = 0; b->acc = 0; b->n = 0;
}

static void bput(Bits *b, unsigned int v, int k) {   /* grava os k bits menos significativos de v (k <= 24) */
    for (b->acc = (b->acc << k) | v, b->n += k; b->n >= 8; b->pos++) {
        b->n -= 8;
        if (b->pos < b->cap) b->buf[b->pos] = (unsigned char)(b->acc >> b->n);
    }
}

static unsigned int bget(Bits *b, int k) {
    for (; b->n < k; b->n += 8) b->acc = (b->acc << 8) | (b->pos < b->cap ? b->buf[b->pos++] : 0u);
    b->n -= k;
    return (b->acc >> b->n) & ((1u << k) - 1);
}

static long bfim(Bits *b) {   /* completa o último byte e devolve o tamanho em bytes */
    if (b->n) bput(b, 0, 8 - b->n);
    return b->pos;
}
