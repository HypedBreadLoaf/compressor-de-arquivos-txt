/* SuperbZip - compressor de arquivos (UFABC - Programação Estruturada 2026.3)
   Compilação: gcc -std=c99 -O2 -Wall -Wextra -o superbzip main.c   (main.c inclui os demais módulos) */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "bits.c"
#include "huffman.c"
#include "bwt.c"
#include "sbz.c"

static const char *ERRO[] = {"", "não foi possível abrir o arquivo de entrada", "arquivo inválido ou corrompido",
    "falha de integridade (CRC32 não confere)", "não foi possível criar o arquivo de saída", "memória insuficiente"};

static int ler(const char *msg, char *s, int limpa) {   /* lê uma linha; 'limpa' remove espaços e aspas */
    int i = 0, j = 0;
    printf("%s", msg);
    fflush(stdout);
    if (!fgets(s, 900, stdin)) return 0;
    while (limpa && (s[i] == ' ' || s[i] == '"' || s[i] == '\'')) i++;
    while (s[i] && s[i] != '\n' && s[i] != '\r') s[j++] = s[i++];
    while (limpa && j > 0 && (s[j - 1] == ' ' || s[j - 1] == '"' || s[j - 1] == '\'')) j--;
    s[j] = 0;
    return 1;
}

static long tamanho(const char *arq) {   /* -1 se o arquivo não existe */
    FILE *f = fopen(arq, "rb");
    long t = -1;
    if (f) { fseek(f, 0, SEEK_END); t = ftell(f); fclose(f); }
    return t;
}

static int ponto(const char *s) {   /* posição da extensão do nome (ou do fim, se não houver) */
    int i, p = -1;
    for (i = 0; s[i]; i++) p = s[i] == '.' ? i : (s[i] == '/' || s[i] == '\\') ? -1 : p;
    return p < 0 ? i : p;
}

static int nome_livre(char *s) {   /* nunca sobrescreve: arq.txt -> arq_1.txt, arq_2.txt, ... */
    char base[1024];
    int i, p = ponto(s), k = 0;
    for (i = 0; (base[i] = s[i]) != 0; i++);
    while (tamanho(s) >= 0) sprintf(s, "%.*s_%d%s", p, base, ++k, base + p);
    return k;
}

static double seg(clock_t t0) { return (double)(clock() - t0) / CLOCKS_PER_SEC; }

int main(void) {
    char op[1024], a[1024], b[1024];
    Info inf;
    clock_t t0;
    double t;
    int r;
    crc_ini();
#ifdef _WIN32
    system("chcp 65001 > nul");
#endif
    for (;;) {
        printf("\n============ SuperbZip - UFABC ============\n"
               " 1) Comprimir\n 2) Descomprimir\n 3) Buscar texto em arquivo comprimido\n"
               " 4) Verificar integridade (.sbz)\n 5) Sair\n");
        if (!ler("Opção: ", op, 1) || (op[0] == '5' && !op[1])) break;
        if (op[0] < '1' || op[0] > '4' || op[1]) { printf("Opção inválida.\n"); continue; }
        if (!ler(op[0] == '1' ? "Arquivo a comprimir: " : "Arquivo comprimido (.sbz): ", a, 1)) break;
        if (op[0] == '1') {
            sprintf(b, "%.*s.sbz", ponto(a), a);
            if (tamanho(a) >= 0 && nome_livre(b)) printf("Já existe um arquivo com esse nome; saída: %s\n", b);
            t0 = clock();
            r = comprimir(a, b);
            t = seg(t0);
            if (!r) printf("Arquivo original:    %-32s Tamanho: %ld Bytes\nArquivo comprimido:  %-32s Tamanho: %ld Bytes\n"
                           "Razão de compressão: %.4f\nTempo de compressão: %.3f s\n", a, tamanho(a), b, tamanho(b),
                           tamanho(a) ? (double)tamanho(b) / tamanho(a) : 0.0, t);
        } else if (op[0] == '2') {
            if (!ler("Nome do arquivo restaurado: ", b, 1)) break;
            if (nome_livre(b)) printf("Já existe um arquivo com esse nome; saída: %s\n", b);
            t0 = clock();
            r = descomprimir(a, b, NULL, &inf);
            t = seg(t0);
            if (!r) printf("Arquivo comprimido:  %-32s Tamanho: %ld Bytes\nArquivo restaurado:  %-32s Tamanho: %ld Bytes\n"
                           "Integridade (CRC32 %08X): OK\nTempo de descompressão: %.3f s\n",
                           a, tamanho(a), b, tamanho(b), inf.crc, t);
        } else if (op[0] == '3') {
            if (!ler("Texto a buscar: ", b, 0)) break;
            if (!b[0]) continue;
            t0 = clock();
            r = descomprimir(a, NULL, b, &inf);
            t = seg(t0);
            if (!r) printf("%ld ocorrência(s) de \"%s\"%s. Tempo de busca: %.3f s\n", inf.ocorr, b,
                           inf.ocorr > 20 ? " (exibidas até 20 linhas)" : "", t);
        } else {
            t0 = clock();
            r = descomprimir(a, NULL, NULL, &inf);
            t = seg(t0);
            if (!r) printf("Arquivo íntegro: %ld Bytes originais em %ld bloco(s), CRC32 %08X confere. Tempo: %.3f s\n",
                           inf.tam, inf.blocos, inf.crc, t);
        }
        if (r) printf("Erro: %s.\n", ERRO[r]);
    }
    return 0;
}
