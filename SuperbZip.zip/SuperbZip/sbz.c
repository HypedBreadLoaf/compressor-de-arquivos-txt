/* sbz.c - Formato .sbz: compressão/descompressão por blocos, CRC32 e busca KMP no arquivo comprimido
   Arquivo: "SBZ1" | tamanho original | blocos (n, linha primária, tamanho dos dados, dados) | CRC32 */
#define BLOCO (1L << 23)   /* 8 MB por bloco */
#define GRUPO 64           /* símbolos por seletor de tabela */
#define CRU 0xFFFFFFFFUL   /* marca de bloco armazenado sem compressão */

typedef struct { unsigned char *s, *out, *sel, *L; int *sa, *rk, *tmp, *cnt; unsigned short *sym; } Ctx;
typedef struct { long tam, blocos, ocorr; unsigned int crc; } Info;

static unsigned int tab_crc[256];

static void crc_ini(void) {
    unsigned int c, i, k;
    for (i = 0; i < 256; tab_crc[i++] = c)
        for (c = i, k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
}

static unsigned int crc_atualiza(unsigned int crc, const unsigned char *p, long n) {
    for (crc = ~crc; n-- > 0; p++) crc = tab_crc[(crc ^ *p) & 0xFF] ^ (crc >> 8);
    return ~crc;
}

static void put32(FILE *f, unsigned long v) {
    int i;
    for (i = 0; i < 4; i++) putc((int)((v >> (8 * i)) & 0xFF), f);
}

static unsigned long get32(FILE *f) {
    unsigned long v = 0;
    int i;
    for (i = 0; i < 4; i++) v |= (unsigned long)(getc(f) & 0xFF) << (8 * i);
    return v;
}

static void *aloca(long n, int *ok) {
    void *p = malloc(n > 0 ? (size_t)n : 1);
    if (!p) *ok = 0;
    return p;
}

static void libera(Ctx *x) {
    free(x->s); free(x->out); free(x->sel); free(x->L); free(x->sa);
    free(x->rk); free(x->tmp); free(x->cnt); free(x->sym);
}

/* Bloco já ordenado pela BWT -> MTF (var 0) ou MTF-2 (var 1) -> frequências -> até 7 tabelas de Huffman */
static long huff_bloco(Ctx *x, long n, int var, const unsigned char *usado, long *prim) {
    long freq[7][ALFA], custo[7], m, i, ini, fim, alvo, acc;
    unsigned char fx[16] = {0}, comp[7][ALFA], mt[7];
    unsigned int cod[7][ALFA];
    int A = 1, T, t, j, v, g, ng, it, melhor;
    Bits b;
    for (i = 0; i < 256; i++) { A += usado[i]; fx[i / 16] |= usado[i]; }
    m = mtf_cod(x->s, n, x->sa, usado, var, x->sym, prim);
    T = m < 200 ? 2 : m < 600 ? 3 : m < 1200 ? 4 : m < 2400 ? 5 : m < 4800 ? 6 : 7;
    ng = (int)((m + GRUPO - 1) / GRUPO);
    for (i = 0; i < A; i++) freq[0][i] = 0;
    for (i = 0; i < m; i++) freq[0][x->sym[i]]++;
    for (t = 0, j = 0, acc = 0; t < T; t++) {   /* tabelas iniciais: faixas de frequência acumulada */
        for (ini = j, alvo = m * (t + 1) / T; j < A && (acc < alvo || j == ini); j++) acc += freq[0][j];
        for (i = 0; i < A; i++) comp[t][i] = (unsigned char)(i >= ini && i < j ? 0 : 15);
    }
    for (it = 0; it < 4; it++) {                /* cada grupo escolhe a tabela mais barata; refaz as árvores */
        for (t = 0; t < T; t++) for (i = 0; i < A; i++) freq[t][i] = 0;
        for (g = 0; g < ng; g++) {
            ini = (long)g * GRUPO;
            fim = ini + GRUPO < m ? ini + GRUPO : m;
            for (t = 0; t < T; t++) for (custo[t] = 0, i = ini; i < fim; i++) custo[t] += comp[t][x->sym[i]];
            for (melhor = 0, t = 1; t < T; t++) if (custo[t] < custo[melhor]) melhor = t;
            for (x->sel[g] = (unsigned char)melhor, i = ini; i < fim; i++) freq[melhor][x->sym[i]]++;
        }
        for (t = 0; t < T; t++) huff_compr(freq[t], A, comp[t]);
    }
    bits_ini(&b, x->out, n);
    for (i = 0; i < 16; i++) bput(&b, fx[i], 1);                     /* bytes presentes no bloco */
    for (i = 0; i < 256; i++) if (fx[i / 16]) bput(&b, usado[i], 1);
    bput(&b, (unsigned)var, 1);
    bput(&b, (unsigned)T, 3);
    bput(&b, (unsigned)(m >> 16), 16);
    bput(&b, (unsigned)(m & 0xFFFF), 16);
    for (t = 0; t < T; t++) mt[t] = (unsigned char)t;
    for (g = 0; g < ng; g++) {                                       /* seletores: MTF + unário */
        for (j = 0; mt[j] != x->sel[g]; j++);
        for (v = j; v > 0; v--) mt[v] = mt[v - 1];
        mt[0] = x->sel[g];
        bput(&b, ((1u << j) - 1) << 1, j + 1);
    }
    for (t = 0; t < T; t++) {                                        /* cabeçalho: comprimentos em delta */
        bput(&b, (unsigned)(v = comp[t][0]), 5);
        for (i = 0; i < A; i++) {
            for (; v < comp[t][i]; v++) bput(&b, 2, 2);
            for (; v > comp[t][i]; v--) bput(&b, 3, 2);
            bput(&b, 0, 1);
        }
        huff_cod(comp[t], A, cod[t]);
    }
    for (i = 0; i < m; i++) {                                        /* dados codificados */
        t = x->sel[i / GRUPO];
        bput(&b, cod[t][x->sym[i]], comp[t][x->sym[i]]);
    }
    return bfim(&b);
}

static long cod_bloco(Ctx *x, long n, long *prim) {   /* BWT uma única vez; mantém a melhor variante de MTF */
    unsigned char usado[256] = {0};
    long i, a, b;
    for (i = 0; i < n; i++) usado[x->s[i]] = 1;
    bwt_ordena(x->s, n, x->sa, x->rk, x->tmp, x->cnt);
    if ((a = huff_bloco(x, n, 0, usado, prim)) >= n) return a;   /* incompressível: será armazenado cru */
    return (b = huff_bloco(x, n, 1, usado, prim)) < a ? b : huff_bloco(x, n, 0, usado, prim);
}

/* Reconstrói tabelas a partir do cabeçalho, decodifica Huffman, desfaz MTF/RLE e a BWT (x->s -> x->out) */
static int dec_bloco(Ctx *x, long tam, long n, long prim) {
    Decod d[7];
    unsigned char lista[256], comp[ALFA], mt[7], fx[16], c;
    long i, k, m, run, pw;
    int nu, A, T, t, j, v, g, ng, dd, var, ult = 1;
    Bits b;
    bits_ini(&b, x->s, tam);
    for (i = 0; i < 16; i++) fx[i] = (unsigned char)bget(&b, 1);
    for (nu = 0, i = 0; i < 256; i++) if (fx[i / 16] && bget(&b, 1)) lista[nu++] = (unsigned char)i;
    A = nu + 1;
    var = (int)bget(&b, 1);
    T = (int)bget(&b, 3);
    m = (long)bget(&b, 16) << 16;
    m |= (long)bget(&b, 16);
    if (nu < 1 || T < 1 || m > n) return 1;
    for (t = 0; t < T; t++) mt[t] = (unsigned char)t;
    for (ng = (int)((m + GRUPO - 1) / GRUPO), g = 0; g < ng; g++) {
        for (j = 0; bget(&b, 1);) if (++j >= T) return 1;
        for (c = mt[j]; j > 0; j--) mt[j] = mt[j - 1];
        x->sel[g] = mt[0] = c;
    }
    for (t = 0; t < T; t++) {
        for (v = (int)bget(&b, 5), i = 0; i < A; comp[i++] = (unsigned char)v) {
            while (bget(&b, 1)) v += bget(&b, 1) ? -1 : 1;
            if (v < 1 || v > MAXL) return 1;
        }
        huff_dec_ini(&d[t], comp, A);
    }
    for (i = k = run = 0, pw = 1; i < m; i++) {
        if ((v = huff_dec(&d[x->sel[i / GRUPO]], &b)) < 0) return 1;
        if (v < 2) {
            run += pw << v;
            pw <<= 1;
            ult = 0;
            if (run > n) return 1;
            continue;
        }
        if (k + run >= n) return 1;
        for (; run > 0; run--) x->L[k++] = lista[0];
        for (pw = 1, j = v - 1, c = lista[j], dd = var && (j > 1 || !ult); j > dd; j--) lista[j] = lista[j - 1];
        x->L[k++] = lista[dd] = c;
        ult = 1;
    }
    if (k + run != n) return 1;
    for (; run > 0; run--) x->L[k++] = lista[0];
    bwt_inversa(x->L, n, prim, x->out, x->sa);
    return 0;
}

/* Retornos: 0 ok, 1 entrada inexistente, 2 inválido/corrompido, 3 CRC difere, 4 erro na saída, 5 sem memória */
static int comprimir(const char *ent, const char *sai) {
    FILE *fi, *fo;
    Ctx x = {0};
    long tam, bs, n, p, prim = 0;
    int ok = 1;
    unsigned int crc = 0;
    if (!(fi = fopen(ent, "rb"))) return 1;
    fseek(fi, 0, SEEK_END);
    tam = ftell(fi);
    rewind(fi);
    if (tam < 0 || tam > 0x7FFFFFFFL || !(fo = fopen(sai, "wb"))) { fclose(fi); return tam < 0 ? 1 : 4; }
    bs = tam < BLOCO ? tam : BLOCO;
    x.s = aloca(bs, &ok); x.out = aloca(bs, &ok); x.sel = aloca(bs / GRUPO + 1, &ok);
    x.sym = aloca(bs * (long)sizeof(unsigned short), &ok);
    x.sa = aloca(bs * (long)sizeof(int), &ok); x.rk = aloca(bs * (long)sizeof(int), &ok);
    x.tmp = aloca(bs * (long)sizeof(int), &ok); x.cnt = aloca((bs + 256) * (long)sizeof(int), &ok);
    fwrite("SBZ1", 1, 4, fo);
    put32(fo, (unsigned long)tam);
    while (ok && (n = (long)fread(x.s, 1, (size_t)bs, fi)) > 0) {
        crc = crc_atualiza(crc, x.s, n);
        if ((p = cod_bloco(&x, n, &prim)) >= n) { p = n; prim = (long)-1; }
        put32(fo, (unsigned long)n);
        put32(fo, prim < 0 ? CRU : (unsigned long)prim);
        put32(fo, (unsigned long)p);
        fwrite(prim < 0 ? x.s : x.out, 1, (size_t)p, fo);
    }
    put32(fo, crc);
    libera(&x);
    fclose(fi);
    if (fclose(fo) || !ok) { remove(sai); return ok ? 4 : 5; }
    return 0;
}

static void mostra(const unsigned char *b, long n, long i, long pm, long lin) {   /* linha da ocorrência */
    long a, e, s = i - pm + 1;
    for (a = s > 0 ? s : 0; a > 0 && b[a - 1] != '\n' && s - a < 90; a--);
    for (e = i + 1; e < n && b[e] != '\n' && e - i < 60; e++);
    printf("  linha %ld: ", lin);
    for (; a < e; a++) {
        if (a == s) putchar('[');
        if (b[a] != '\r') putchar(b[a]);
        if (a == i) putchar(']');
    }
    putchar('\n');
}

/* Descomprime para 'sai' (se não nulo) e/ou busca 'pad' (KMP) nos blocos, sem gravar nada em disco */
static int descomprimir(const char *ent, const char *sai, const char *pad, Info *inf) {
    FILE *fi, *fo = NULL;
    Ctx x = {0};
    unsigned char mg[4], *blk = NULL;
    const unsigned char *P = (const unsigned char *)pad;
    unsigned long n, prim, p;
    long bs, i, lin = 1, ult = 0, tot = 0, vistas = 0;
    int r = 0, ok = 1, q = 0, pm = 0, f[1024];
    if (!(fi = fopen(ent, "rb"))) return 1;
    if (fread(mg, 1, 4, fi) != 4 || mg[0] != 'S' || mg[1] != 'B' || mg[2] != 'Z' || mg[3] != '1') { fclose(fi); return 2; }
    inf->tam = (long)get32(fi);
    inf->blocos = inf->ocorr = 0;
    inf->crc = 0;
    bs = inf->tam < BLOCO ? inf->tam : BLOCO;
    if (sai && !(fo = fopen(sai, "wb"))) { fclose(fi); return 4; }
    x.s = aloca(bs, &ok); x.L = aloca(bs, &ok); x.out = aloca(bs, &ok);
    x.sel = aloca(bs / GRUPO + 1, &ok); x.sa = aloca(bs * (long)sizeof(int), &ok);
    if (P) for (f[0] = 0, pm = 1; P[pm] && pm < 1000; pm++) {   /* função de falha do KMP */
        while (q && P[pm] != P[q]) q = f[q - 1];
        f[pm] = q += P[pm] == P[q];
    }
    for (q = 0; !r && tot < inf->tam; tot += (long)n, inf->blocos++) {
        n = get32(fi); prim = get32(fi); p = get32(fi);
        if (!ok) r = 5;
        else if (n < 1 || n > (unsigned long)bs || p > n || fread(x.s, 1, p, fi) != p) r = 2;
        else if (prim == CRU) { if (p != n) r = 2; blk = x.s; }
        else if (prim >= n || dec_bloco(&x, (long)p, (long)n, (long)prim)) r = 2;
        else blk = x.out;
        if (r) break;
        inf->crc = crc_atualiza(inf->crc, blk, (long)n);
        if (fo) fwrite(blk, 1, n, fo);
        for (i = 0; P && i < (long)n; lin += blk[i++] == '\n') {   /* busca KMP contínua entre blocos */
            while (q && blk[i] != P[q]) q = f[q - 1];
            if (blk[i] == P[q] && ++q == pm) {
                q = f[q - 1];
                inf->ocorr++;
                if (lin != ult && vistas++ < 20) mostra(blk, (long)n, i, pm, ult = lin);
            }
        }
    }
    if (!r && (tot != inf->tam || get32(fi) != inf->crc)) r = 3;
    libera(&x);
    fclose(fi);
    if (fo && (fclose(fo) || r)) { remove(sai); return r ? r : 4; }
    return r;
}
