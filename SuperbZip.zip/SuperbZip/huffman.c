/* huffman.c - TAD Árvore de Huffman (com fila de prioridade) e TAD Dicionário de códigos canônicos */
#define MAXL 20    /* comprimento máximo de um código */
#define ALFA 258   /* tamanho máximo do alfabeto */

typedef struct { short cont[MAXL + 1], simb[ALFA]; } Decod;   /* dicionário de decodificação */

static void heap_ins(int *h, int *hn, int x, const long *w) {
    int i;
    for (i = (*hn)++; i > 0 && w[h[(i - 1) / 2]] > w[x]; i = (i - 1) / 2) h[i] = h[(i - 1) / 2];
    h[i] = x;
}

static int heap_rem(int *h, int *hn, const long *w) {
    int topo = h[0], x = h[--*hn], i = 0, f;
    for (; (f = 2 * i + 1) < *hn; i = f) {
        if (f + 1 < *hn && w[h[f + 1]] < w[h[f]]) f++;
        if (w[x] <= w[h[f]]) break;
        h[i] = h[f];
    }
    h[i] = x;
    return topo;
}

/* Constrói a árvore a partir das frequências e devolve a profundidade (comprimento do código) de cada símbolo */
static void huff_compr(const long *freq, int A, unsigned char *comp) {
    long w[2 * ALFA];
    int h[ALFA], pai[2 * ALFA], prof[2 * ALFA], hn, i, a, no, mx;
    for (i = 0; i < A; i++) w[i] = freq[i] ? freq[i] : 1;
    for (;;) {
        for (hn = 0, i = 0; i < A; i++) heap_ins(h, &hn, i, w);
        for (no = A; hn > 1; no++) {   /* une os dois nós de menor peso */
            a = heap_rem(h, &hn, w);
            i = heap_rem(h, &hn, w);
            w[no] = w[a] + w[i];
            pai[a] = pai[i] = no;
            heap_ins(h, &hn, no, w);
        }
        for (prof[no - 1] = 0, i = no - 2; i >= 0; i--) prof[i] = prof[pai[i]] + 1;
        for (mx = 0, i = 0; i < A; i++) if ((comp[i] = (unsigned char)prof[i]) > mx) mx = comp[i];
        if (mx <= MAXL) return;
        for (i = 0; i < A; i++) w[i] = w[i] / 2 + 1;   /* árvore profunda demais: achata os pesos */
    }
}

static void huff_cod(const unsigned char *comp, int A, unsigned int *cod) {   /* códigos canônicos */
    unsigned int cont[MAXL + 1] = {0}, prox[MAXL + 1], c = 0;
    int i;
    for (i = 0; i < A; i++) cont[comp[i]]++;
    for (cont[0] = 0, i = 1; i <= MAXL; i++) prox[i] = c = (c + cont[i - 1]) << 1;
    for (i = 0; i < A; i++) cod[i] = prox[comp[i]]++;
}

static void huff_dec_ini(Decod *d, const unsigned char *comp, int A) {
    short off[MAXL + 2];
    int i;
    for (i = 0; i <= MAXL; i++) d->cont[i] = 0;
    for (i = 0; i < A; i++) d->cont[comp[i]]++;
    for (off[1] = 0, i = 1; i < MAXL; i++) off[i + 1] = (short)(off[i] + d->cont[i]);
    for (i = 0; i < A; i++) d->simb[off[comp[i]]++] = (short)i;
}

static int huff_dec(const Decod *d, Bits *b) {   /* lê bits até formar um código válido */
    int cod = 0, prim = 0, ind = 0, l;
    for (l = 1; l <= MAXL; l++) {
        cod |= (int)bget(b, 1);
        if (cod - d->cont[l] < prim) return d->simb[ind + cod - prim];
        ind += d->cont[l];
        prim = (prim + d->cont[l]) << 1;
        cod <<= 1;
    }
    return -1;
}
